from flask import Flask
from flask import render_template,jsonify
from flask import request, redirect
import datetime
from random import uniform

def current_time(): #for the current time
    #gets the current date and time
    now = datetime.datetime.now()
    #format as a string
    date_time = now.strftime("%m/%d/%Y, %H:%M:%S")
    return date_time 

def random_temperature(): #gets random temperature
    temperature=uniform(15,40) 
    return str(round(temperature,2)) 

def random_humidity(): #gets random humidity 
    humidity=uniform(0,100)
    return str(round(humidity,2))

def random_light(): #gets random light 
    light=uniform(0,1000)
    return str(round(light,2))

def sensor_id(): 
    sensor=5363233 #student id
    return str(sensor)

def AppendFunction(sampleList): 
    sample=(current_time(),
            random_temperature(), 
            random_humidity(), 
            random_light(), 
            sensor_id()
            )
    sampleList.append(sample)
    if len(sampleList)>5:
        return sampleList.clear()
    else:
        return sampleList

def JsonSamples(sampleList):
    currentSample=[]
    for sample in sampleList:
        currentSample=sample
    return currentSample

def calculates(data,key): #calculating the min, max and average
    statistics=[]
    for sample in data:
        num=sample.get(key)
        statistics.append(float(num))
    return {
            'minimal': round(min(statistics),2),
            'maximum': round(max(statistics),2),
            'average': round(sum(statistics) / len(statistics),2)
        }

def size(sample):  
    if len(data)==5:
        data.pop(0)
    return data.append(sample)

samples=[]
data=[]

app=Flask(__name__)

#Uses the random generated data 
# @app.route('/')
# def Display():
#     AppendFunction(samples)
#     return render_template('index.html',
#                             time=current_time(),
#                             temperature=random_temperature(),
#                             humidity=random_humidity(),
#                             light_level=random_light(),
#                             sensor_id=sensor_id(),
#                             samples=samples
#                             )



@app.route('/')
def Display():
    current_sample=JsonSamples(data)
    return render_template('index.html',
                            time=current_sample['timestamp'],
                            temperature=current_sample['temperature'],
                            humidity=current_sample['humidity'],
                            light_level=current_sample['light_level'],
                            sensor_id=current_sample['sensor_id'],
                            temp=calculates(data,'temperature'),
                            hum=calculates(data,'humidity'),
                            light=calculates(data,'light_level'),
                            samples=data
                           )

# For the json data
# @app.route("/post_data", methods=['POST'])
# def receive_data():
#     json_data = request.get_json()
#     if json_data:
#         json_data = request.json
#         sensor_id = json_data.get('sensor_id')
#         timestamp = json_data.get('timestamp')
#         temperature = json_data.get('temperature')
#         humidity = json_data.get('humidity')
#         light_level = json_data.get('light_level')

#         sample = {
#             'sensor_id': sensor_id,
#             'timestamp': timestamp,
#             'temperature': temperature,
#             'humidity': humidity,
#             'light_level': light_level
#          }
       
#         data.append(sample)

#         return jsonify({"message": "Data received successfully", "data": sample}), 200  # OK
#     else:
#         return jsonify({"error": "No data provided"}), 400  # Error


#For the arduino data
@app.route("/post_data", methods=['POST'])
def receive_data():
    json_data = request.get_json()
    if json_data:
        size(json_data)
        return jsonify({"message": "Data received successfully", "data": json_data}), 200
    else:
        return jsonify({"error": "No data provided"}), 400

if __name__ == "__main__":
    app.run(port=5001, debug=True)