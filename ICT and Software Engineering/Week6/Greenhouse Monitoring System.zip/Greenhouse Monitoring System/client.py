import serial
import requests
import json
import time

url = "http://localhost:5001/post_data"

# Main program
if __name__ == "__main__":
    # Open the serial port, change it as per your setup (e.g., "COM4" or "/dev/tty0*")
    with serial.Serial("COM4", 9600, timeout=5) as ser:
        time.sleep(0.5)  
        try:
            while True:
                time.sleep(0.5) 

                data_line = ser.readline().decode().strip() 
                data_values = data_line.split(',')

                if len(data_values) == 3:
                    try:
                        temperature, humidity, light_level = data_values
                        print(f"Raw data received: {data_values}")

                        # Continue with processing
                        print(f"Sensor ID: {1}, Temperature: {temperature}, Humidity: {humidity}, Light Level: {light_level}")
                        
                        payload = {
                            "sensor_id": 1,
                            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                            "temperature": temperature,
                            "humidity": humidity,
                            "light_level": light_level
                        }

                        # Send POST request to Flask server
                        response = requests.post(url, json=payload)
                        print(response.json())

                    except ValueError:
                        print(f"Invalid data format: {data_line}")

                else:
                    print(f"Error: Expected 4 values, received {len(data_values)}: {data_line}")

        except KeyboardInterrupt:
            print("Program terminated by user.")
