"""
This program reads input from a file in JSON format and sends
HTTP POST requests to localhost:5000 for each sample in the file.
"""
import requests
import json
input_file = "data.json"
url = "http://localhost:5001/post_data"
# Open the JSON file
with open(input_file, 'r') as file:
    # Load data from JSON file
    sensor_data = json.load(file)
    # Process each item in the JSON data
    for item in sensor_data:
    # Make the POST request with the data item
        response = requests.post(url, json=item)
        # Check if the response status code indicates an error
        if response.status_code != 200:
            print(f"Failed to post data: {response.text}")