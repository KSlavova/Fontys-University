﻿namespace SnackBar
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            nmBurger = new NumericUpDown();
            nmPepsi = new NumericUpDown();
            nmFries = new NumericUpDown();
            label1 = new Label();
            placeOrder = new Button();
            snackPlace = new TabControl();
            tabPage1 = new TabPage();
            groupBox5 = new GroupBox();
            label12 = new Label();
            txtName = new TextBox();
            lbTxt = new Label();
            label13 = new Label();
            OrderTxtBox = new Button();
            txtAmount = new TextBox();
            groupBox4 = new GroupBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label14 = new Label();
            tabPage2 = new TabPage();
            groupBox3 = new GroupBox();
            label9 = new Label();
            newSnack = new TextBox();
            label10 = new Label();
            button2 = new Button();
            newPrice = new TextBox();
            newAmount = new TextBox();
            label11 = new Label();
            groupBox2 = new GroupBox();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton3 = new RadioButton();
            label7 = new Label();
            nmPrice = new NumericUpDown();
            label8 = new Label();
            nmStock = new NumericUpDown();
            button1 = new Button();
            groupBox1 = new GroupBox();
            bRevenue = new Button();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)nmBurger).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmPepsi).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmFries).BeginInit();
            snackPlace.SuspendLayout();
            tabPage1.SuspendLayout();
            groupBox5.SuspendLayout();
            groupBox4.SuspendLayout();
            tabPage2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nmPrice).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmStock).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // nmBurger
            // 
            nmBurger.Location = new Point(246, 57);
            nmBurger.Name = "nmBurger";
            nmBurger.Size = new Size(98, 31);
            nmBurger.TabIndex = 3;
            // 
            // nmPepsi
            // 
            nmPepsi.Location = new Point(246, 153);
            nmPepsi.Name = "nmPepsi";
            nmPepsi.Size = new Size(98, 31);
            nmPepsi.TabIndex = 4;
            // 
            // nmFries
            // 
            nmFries.Location = new Point(246, 251);
            nmFries.Name = "nmFries";
            nmFries.Size = new Size(98, 31);
            nmFries.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BorderStyle = BorderStyle.Fixed3D;
            label1.Location = new Point(61, 418);
            label1.Name = "label1";
            label1.Size = new Size(2, 27);
            label1.TabIndex = 6;
            // 
            // placeOrder
            // 
            placeOrder.Location = new Point(125, 331);
            placeOrder.Name = "placeOrder";
            placeOrder.Size = new Size(112, 34);
            placeOrder.TabIndex = 7;
            placeOrder.Text = "Order";
            placeOrder.UseVisualStyleBackColor = true;
            placeOrder.Click += placeOrder_Click;
            // 
            // snackPlace
            // 
            snackPlace.Controls.Add(tabPage1);
            snackPlace.Controls.Add(tabPage2);
            snackPlace.Location = new Point(38, 21);
            snackPlace.Name = "snackPlace";
            snackPlace.SelectedIndex = 0;
            snackPlace.Size = new Size(798, 716);
            snackPlace.TabIndex = 8;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(groupBox5);
            tabPage1.Controls.Add(groupBox4);
            tabPage1.Controls.Add(label14);
            tabPage1.Location = new Point(4, 34);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(790, 678);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Client";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(label12);
            groupBox5.Controls.Add(txtName);
            groupBox5.Controls.Add(lbTxt);
            groupBox5.Controls.Add(label13);
            groupBox5.Controls.Add(OrderTxtBox);
            groupBox5.Controls.Add(txtAmount);
            groupBox5.Location = new Point(453, 35);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(300, 507);
            groupBox5.TabIndex = 19;
            groupBox5.TabStop = false;
            groupBox5.Text = "Order new snack:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(23, 48);
            label12.Name = "label12";
            label12.Size = new Size(191, 25);
            label12.TabIndex = 11;
            label12.Text = "Enter new snack name:";
            // 
            // txtName
            // 
            txtName.Location = new Point(23, 92);
            txtName.Name = "txtName";
            txtName.Size = new Size(150, 31);
            txtName.TabIndex = 14;
            // 
            // lbTxt
            // 
            lbTxt.AutoSize = true;
            lbTxt.BorderStyle = BorderStyle.FixedSingle;
            lbTxt.Location = new Point(66, 407);
            lbTxt.Name = "lbTxt";
            lbTxt.Size = new Size(2, 27);
            lbTxt.TabIndex = 17;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(23, 193);
            label13.Name = "label13";
            label13.Size = new Size(123, 25);
            label13.TabIndex = 12;
            label13.Text = "Enter amount:";
            // 
            // OrderTxtBox
            // 
            OrderTxtBox.Location = new Point(113, 329);
            OrderTxtBox.Name = "OrderTxtBox";
            OrderTxtBox.Size = new Size(112, 34);
            OrderTxtBox.TabIndex = 16;
            OrderTxtBox.Text = "Order";
            OrderTxtBox.UseVisualStyleBackColor = true;
            OrderTxtBox.Click += OrderTxtBox_Click;
            // 
            // txtAmount
            // 
            txtAmount.Location = new Point(23, 246);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(150, 31);
            txtAmount.TabIndex = 15;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(label3);
            groupBox4.Controls.Add(nmBurger);
            groupBox4.Controls.Add(label4);
            groupBox4.Controls.Add(nmPepsi);
            groupBox4.Controls.Add(label5);
            groupBox4.Controls.Add(nmFries);
            groupBox4.Controls.Add(label1);
            groupBox4.Controls.Add(placeOrder);
            groupBox4.Location = new Point(22, 24);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(385, 518);
            groupBox4.TabIndex = 18;
            groupBox4.TabStop = false;
            groupBox4.Text = "Choose a snack:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(61, 63);
            label3.Name = "label3";
            label3.Size = new Size(64, 25);
            label3.TabIndex = 8;
            label3.Text = "Burger";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(61, 172);
            label4.Name = "label4";
            label4.Size = new Size(53, 25);
            label4.TabIndex = 9;
            label4.Text = "Pepsi";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(61, 257);
            label5.Name = "label5";
            label5.Size = new Size(48, 25);
            label5.TabIndex = 10;
            label5.Text = "Fries";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(502, 117);
            label14.Name = "label14";
            label14.Size = new Size(0, 25);
            label14.TabIndex = 13;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(groupBox3);
            tabPage2.Controls.Add(groupBox2);
            tabPage2.Controls.Add(groupBox1);
            tabPage2.Location = new Point(4, 34);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(790, 678);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Owner";
            tabPage2.UseVisualStyleBackColor = true;
            tabPage2.Click += tabPage2_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(label9);
            groupBox3.Controls.Add(newSnack);
            groupBox3.Controls.Add(label10);
            groupBox3.Controls.Add(button2);
            groupBox3.Controls.Add(newPrice);
            groupBox3.Controls.Add(newAmount);
            groupBox3.Controls.Add(label11);
            groupBox3.Location = new Point(18, 434);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(686, 212);
            groupBox3.TabIndex = 22;
            groupBox3.TabStop = false;
            groupBox3.Text = "Create new snack:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(6, 43);
            label9.Name = "label9";
            label9.Size = new Size(142, 25);
            label9.TabIndex = 14;
            label9.Text = "Enter new snack:";
            // 
            // newSnack
            // 
            newSnack.Location = new Point(6, 71);
            newSnack.Name = "newSnack";
            newSnack.Size = new Size(168, 31);
            newSnack.TabIndex = 13;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(258, 40);
            label10.Name = "label10";
            label10.Size = new Size(99, 25);
            label10.TabIndex = 15;
            label10.Text = "Enter price:";
            // 
            // button2
            // 
            button2.Location = new Point(258, 153);
            button2.Name = "button2";
            button2.Size = new Size(161, 34);
            button2.TabIndex = 19;
            button2.Text = "Save new snack";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // newPrice
            // 
            newPrice.Location = new Point(258, 71);
            newPrice.Name = "newPrice";
            newPrice.Size = new Size(150, 31);
            newPrice.TabIndex = 17;
            // 
            // newAmount
            // 
            newAmount.Location = new Point(453, 74);
            newAmount.Name = "newAmount";
            newAmount.Size = new Size(150, 31);
            newAmount.TabIndex = 18;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(453, 40);
            label11.Name = "label11";
            label11.Size = new Size(123, 25);
            label11.TabIndex = 16;
            label11.Text = "Enter amount:";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(radioButton1);
            groupBox2.Controls.Add(radioButton2);
            groupBox2.Controls.Add(radioButton3);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(nmPrice);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(nmStock);
            groupBox2.Controls.Add(button1);
            groupBox2.Location = new Point(18, 192);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(675, 212);
            groupBox2.TabIndex = 21;
            groupBox2.TabStop = false;
            groupBox2.Text = "Choose what you want to change?";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(6, 46);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(97, 29);
            radioButton1.TabIndex = 2;
            radioButton1.TabStop = true;
            radioButton1.Text = "Burgers";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(6, 81);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(78, 29);
            radioButton2.TabIndex = 3;
            radioButton2.TabStop = true;
            radioButton2.Text = "Pepsi";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(6, 116);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(73, 29);
            radioButton3.TabIndex = 4;
            radioButton3.TabStop = true;
            radioButton3.Text = "Fries";
            radioButton3.UseVisualStyleBackColor = true;
            radioButton3.CheckedChanged += radioButton3_CheckedChanged;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(258, 48);
            label7.Name = "label7";
            label7.Size = new Size(136, 25);
            label7.TabIndex = 8;
            label7.Text = "Enter new price:";
            // 
            // nmPrice
            // 
            nmPrice.DecimalPlaces = 2;
            nmPrice.Location = new Point(468, 42);
            nmPrice.Name = "nmPrice";
            nmPrice.Size = new Size(108, 31);
            nmPrice.TabIndex = 10;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(258, 98);
            label8.Name = "label8";
            label8.Size = new Size(190, 25);
            label8.TabIndex = 9;
            label8.Text = "Enter the new amount:";
            label8.Click += label8_Click;
            // 
            // nmStock
            // 
            nmStock.Location = new Point(468, 92);
            nmStock.Name = "nmStock";
            nmStock.Size = new Size(153, 31);
            nmStock.TabIndex = 11;
            // 
            // button1
            // 
            button1.Location = new Point(207, 160);
            button1.Name = "button1";
            button1.Size = new Size(255, 34);
            button1.TabIndex = 12;
            button1.Text = "Save changes";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(bRevenue);
            groupBox1.Controls.Add(label2);
            groupBox1.Location = new Point(18, 15);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(298, 150);
            groupBox1.TabIndex = 20;
            groupBox1.TabStop = false;
            groupBox1.Text = "Show revenue";
            // 
            // bRevenue
            // 
            bRevenue.Location = new Point(18, 93);
            bRevenue.Name = "bRevenue";
            bRevenue.Size = new Size(203, 34);
            bRevenue.TabIndex = 1;
            bRevenue.Text = "Show revenue";
            bRevenue.UseVisualStyleBackColor = true;
            bRevenue.Click += bRevenue_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BorderStyle = BorderStyle.Fixed3D;
            label2.Location = new Point(27, 50);
            label2.Name = "label2";
            label2.Size = new Size(2, 27);
            label2.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(869, 778);
            Controls.Add(snackPlace);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)nmBurger).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmPepsi).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmFries).EndInit();
            snackPlace.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            tabPage2.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nmPrice).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmStock).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private NumericUpDown nmBurger;
        private NumericUpDown nmPepsi;
        private NumericUpDown nmFries;
        private Label label1;
        private Button placeOrder;
        private TabControl snackPlace;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Button bRevenue;
        private Label label2;
        private Label label5;
        private Label label4;
        private Label label3;
        private RadioButton radioButton3;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private NumericUpDown nmStock;
        private NumericUpDown nmPrice;
        private Label label8;
        private Label label7;
        private Button button1;
        private Label label11;
        private Label label10;
        private Label label9;
        private TextBox newSnack;
        private Button button2;
        private TextBox newAmount;
        private TextBox newPrice;
        private TextBox txtAmount;
        private TextBox txtName;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label lbTxt;
        private Button OrderTxtBox;
        private GroupBox groupBox2;
        private GroupBox groupBox1;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private GroupBox groupBox5;
    }
}
