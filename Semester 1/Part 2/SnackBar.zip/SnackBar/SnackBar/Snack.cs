﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnackBar
{
    public class Snack
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public int AmountInStock { get; set; }

        public Snack(string name, double price, int amountInStock)
        {
            Name = name;
            Price = price;
            AmountInStock = amountInStock;
        }

        public bool DecreaseStock(int amount)
        {
            if(AmountInStock>=amount)
            {
                AmountInStock -= amount;
                return true;
            }
            return false;
        }

        //public string GetName()
        //{
        //    return Name;
        //}

        //public string GetPrice()
        //{
        //    return $"{Price}";
        //}

        //public string GetAmountInStock()
        //{
        //    return $"{AmountInStock}";
        //}
    }
}
