namespace SnackBar
{
    public partial class Form1 : Form
    {
        private SnackBar snackBar;

        public Form1()
        {
            InitializeComponent();
            snackBar = new SnackBar();
        }

        private void placeOrder_Click(object sender, EventArgs e)
        {
            string total = snackBar.ProcessOrder((int)nmBurger.Value, (int)nmPepsi.Value, (int)nmFries.Value);
            if (total.Contains("We don't have enough: "))
            {
                MessageBox.Show(total);
            }
            else
            {
                label1.Text = total;
            }

        }

        private void bRevenue_Click(object sender, EventArgs e)
        {
            label2.Text = $"Revenue: {snackBar.GetRevenue():f2}";
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //save changes
            if (radioButton1.Checked)
            {
                snackBar.UpdatePriceAndAmount(0, (double)nmPrice.Value, (int)nmStock.Value);
            }
            else if (radioButton2.Checked)
            {
                snackBar.UpdatePriceAndAmount(1, (double)nmPrice.Value, (int)nmStock.Value);
            }
            else
            {
                snackBar.UpdatePriceAndAmount(2, (double)nmPrice.Value, (int)nmStock.Value);
            }
            nmPrice.Value = 0;
            nmStock.Value = 0;
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //save new snack
            snackBar.AddNewSnack(newSnack.Text, double.Parse(newPrice.Text), int.Parse(newAmount.Text));
            newSnack.Text = null;
            newPrice.Text = null;
            newAmount.Text = null;
        }

        private void OrderTxtBox_Click(object sender, EventArgs e)
        {
            //order button 2
            string total = snackBar.ProcessNewSnackOrder(txtName.Text,int.Parse(txtAmount.Text));
            if(total.Contains("We don't have enough: ") || total.Contains("We don't offer "))
            {
                MessageBox.Show(total);
            }
            else
            {
                lbTxt.Text = total; 
            }
        }
    }
}
