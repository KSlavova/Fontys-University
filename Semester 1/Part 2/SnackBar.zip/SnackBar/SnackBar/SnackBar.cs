﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace SnackBar
{
    public class SnackBar
    {
        private List<Snack> allSnacks=new List<Snack>();
        private double revenue;
        public SnackBar() 
        {
            allSnacks.Add(new Snack("Burger",3.40,20));
            allSnacks.Add(new Snack("Pepsi", 2.50,45));
            allSnacks.Add(new Snack("Fries",2.30,70));
        }

        public string ProcessOrder(int snack1, int snack2, int snack3)
        {
            List<string> outOfLimit = new List<string>();
            if (allSnacks[0].DecreaseStock(snack1) == false)
            {
                outOfLimit.Add(allSnacks[0].Name);
            }
            if(allSnacks[1].DecreaseStock(snack2) == false)
            {
                outOfLimit.Add(allSnacks[1].Name);
            }
            if (allSnacks[2].DecreaseStock(snack3) == false)
            {
                outOfLimit.Add(allSnacks[2].Name);
            }
            if(outOfLimit.Count>0)
            {
                return "We don't have enough: " + string.Join(',', outOfLimit);
            }

            double total = (allSnacks[0].Price * snack1) + (allSnacks[1].Price * snack2) + (allSnacks[2].Price * snack3);
            revenue += total;
            return $"Total price: {total:f2}";   
        }

        public double GetRevenue()
        {
            return revenue;
        }

        public void UpdatePriceAndAmount(int snackIndex,double price,int amount)
        {
            allSnacks[snackIndex].Price = price;
            allSnacks[snackIndex].AmountInStock = amount;
        }

        public void AddNewSnack(string name,double price,int amount)
        {
            allSnacks.Add(new Snack(name, price, amount));  
        }

        public string ProcessNewSnackOrder(string name, int amount)
        { 
            foreach (var snack in allSnacks)
            {
                if(snack.Name.Equals(name,StringComparison.OrdinalIgnoreCase))
                {
                    if(snack.DecreaseStock(amount)==false)
                    {
                        return "We don't have enough: " + snack.Name;
                    }

                    double total = snack.Price * amount;
                    revenue += total;
                    return $"Total price: {total:f2}";
                }
            }
            return "We don't offer " + name;
        }
    }
}
