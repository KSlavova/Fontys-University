﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace ExtendingStudentGroup
{
    public class ProjectGroup
    {
        public int Id { get; set; }
        public string Name { get; set; }
        private List<Member> members;
        public string connectionString { get; set; }
        public ProjectGroup()
        {
            members = new List<Member>();
        }
        public ProjectGroup(string name, string connectionString)
        {
            this.Name = name;
            members= new List<Member>();
            this.connectionString= connectionString;
        }

        public void CreateProject()
        {
            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                string sql = "INSERT INTO ProjectGroup (Name) VALUES (@Name)";
                using SqlCommand command = new SqlCommand(sql,connection);
                command.Parameters.AddWithValue("@Name",this.Name);

                connection.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Project group added successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public override string ToString()
        {
            return $"{this.Name}";
        }
    }
}
