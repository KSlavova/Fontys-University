using Microsoft.Data.SqlClient;

namespace ExtendingStudentGroup
{
    public partial class Form1 : Form
    {
        private const string connectionString = "Server=DESKTOP-GPBCRNQ;Database=ExtendedStudentGroup;Trusted_Connection=True; TrustServerCertificate=True;";
        public Form1()
        {
            InitializeComponent();
            UpdateCmbProjectGroups();
            UpdateCmbRemove();
        }

        private void btnCreateStudent_Click(object sender, EventArgs e)
        {
            string studentName = tbxStudentName.Text;
            int studentNumber = int.Parse(tbxNumber.Text);

            if (!string.IsNullOrEmpty(studentName) || studentNumber != null)
            {
                ProjectGroup selectedGroup = (ProjectGroup)cmbProjectGroups.SelectedItem;
                Member newMember = new Member(studentName, studentNumber, connectionString);
                newMember.CreateMember();
                UpdateCmbRemove();
            }
            else
            {
                MessageBox.Show("Please enter valid data for the member.");
            }
        }

        private void btnCreateProject_Click(object sender, EventArgs e) 
        {
            string projectName = tbxProject.Text;
            if (!string.IsNullOrEmpty(projectName))
            {
                ProjectGroup newGroup = new ProjectGroup(projectName,connectionString);
                newGroup.CreateProject();
                UpdateCmbProjectGroups();
            }
            else
            {
                MessageBox.Show("Please enter valid name for the group!");
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void UpdateCmbProjectGroups() 
        {
            cmbProjectGroups.Items.Clear();

            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                string sql = "SELECT * FROM ProjectGroup";
                using SqlCommand command = new SqlCommand(sql, connection);

                connection.Open();
                using SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cmbProjectGroups.Items.Add(new ProjectGroup
                    {
                        Id = Convert.ToInt32(reader["ProjectGroupID"]),
                        Name = reader["Name"].ToString(),
                        connectionString=Form1.connectionString
                    });
                }
                cmbProjectGroups.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnData_Click(object sender, EventArgs e)
        {
            LoadMembers();
        }

        private void LoadMembers() 
        {
            lsbProjectGroup.Items.Clear();
            ProjectGroup selectedGroup = (ProjectGroup)cmbProjectGroups.SelectedItem;
            int id = selectedGroup.Id;
            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                string sql = "SELECT m.Name, m.StudentNumber FROM Member AS m INNER JOIN ProjectGroupMember AS pgm on m.Id=pgm.MemberID WHERE pgm.ProjectGroupID=@GroupId";
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@GroupId", id);

                connection.Open();
                using SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string name = reader["Name"].ToString();
                    int studentNumber = Convert.ToInt32(reader["StudentNumber"]);
                    lsbProjectGroup.Items.Add($"{name} (Student Number: {studentNumber})");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnRemoveStudent_Click(object sender, EventArgs e)
        {
            Member selectedMember = (Member)cmbRemoveStudent.SelectedItem;
            ProjectGroup selectedGroup = (ProjectGroup)cmbProjectGroups.SelectedItem;  
            int memberId = selectedMember.Id;
            int groupId = selectedGroup.Id;

            int id = selectedMember.Id;
            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                string sql = "DELETE FROM ProjectGroupMember WHERE MemberID = @MemberId AND ProjectGroupID = @GroupId";
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@MemberId", memberId);
                command.Parameters.AddWithValue("@GroupId", groupId);

                connection.Open();
                int rows = command.ExecuteNonQuery();
                if (rows > 0)
                {
                    MessageBox.Show("Member removed successfully!");
                    LoadMembers();
                }
                else
                {
                    MessageBox.Show("Member was not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void UpdateCmbRemove()  
        {
            cmbRemoveStudent.Items.Clear();
            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                string sql = "SELECT Id, Name FROM Member";
                using SqlCommand command = new SqlCommand(sql, connection);
                connection.Open();
                using SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cmbRemoveStudent.Items.Add(new Member
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Name = reader["Name"].ToString(),
                        connectionString = Form1.connectionString
                    });
                }
                cmbRemoveStudent.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnChangeName_Click(object sender, EventArgs e)
        {
            string newName = tbxProject.Text;
            ProjectGroup selectedGroup = (ProjectGroup)cmbProjectGroups.SelectedItem;
            int id = selectedGroup.Id;

            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                string sql = "UPDATE ProjectGroup SET Name=@Name WHERE ProjectGroupID=@Id";
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@Name", newName);
                command.Parameters.AddWithValue("@Id", id);

                connection.Open();
                int rows = command.ExecuteNonQuery();
                if (rows > 0)
                {
                    MessageBox.Show("The project name is updated!");
                    UpdateCmbProjectGroups();
                }
                else
                {
                    MessageBox.Show("Project not found!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAssign_Click(object sender, EventArgs e)
        {
            Member selectedMember = (Member)cmbRemoveStudent.SelectedItem;
            ProjectGroup selectedGroup = (ProjectGroup)cmbProjectGroups.SelectedItem;
            int memberId = selectedMember.Id;
            int groupId = selectedGroup.Id;

            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                string sql = "INSERT INTO ProjectGroupMember (ProjectGroupID, MemberID) VALUES (@ProjectGroupId, @MemberId)"; 
                SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@ProjectGroupId",groupId);
                command.Parameters.AddWithValue("@MemberId", memberId);

                connection.Open();
                int rows = command.ExecuteNonQuery();
                if(rows > 0)
                {
                    MessageBox.Show("Member successfully assigned to the group!");
                    LoadMembers();
                }
                else
                {
                    MessageBox.Show("Failed to assign the member to the group.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
