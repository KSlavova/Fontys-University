﻿using Microsoft.Data.SqlClient;

namespace ExtendingStudentGroup
{
    public class Member
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int StudentNumber { get; set; }
        public string connectionString;

        public Member()
        {
           
        }
        public Member(string Name, int studentNumber, string connectionString)
        {
            this.Name = Name;
            this.StudentNumber = studentNumber;
            this.connectionString = connectionString;
        }

        public override string ToString()
        {
            return this.Name;
        }

        public void CreateMember()
        {
            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                string sql = "INSERT INTO Member (Name, StudentNumber) VALUES (@Name, @StudentNumber)";
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@Name", this.Name);
                command.Parameters.AddWithValue("@StudentNUmber", this.StudentNumber);

                connection.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Member added successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
