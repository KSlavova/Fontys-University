﻿namespace ExtendingStudentGroup
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            tbxStudentName = new TextBox();
            tbxNumber = new TextBox();
            btnCreateStudent = new Button();
            label3 = new Label();
            tbxProject = new TextBox();
            btnCreateProject = new Button();
            btnRemoveStudent = new Button();
            btnChangeName = new Button();
            lsbProjectGroup = new ListBox();
            btnData = new Button();
            label4 = new Label();
            cmbProjectGroups = new ComboBox();
            cmbRemoveStudent = new ComboBox();
            label5 = new Label();
            btnAssign = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 25);
            label1.Name = "label1";
            label1.Size = new Size(63, 25);
            label1.TabIndex = 0;
            label1.Text = "Name:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 68);
            label2.Name = "label2";
            label2.Size = new Size(147, 25);
            label2.TabIndex = 1;
            label2.Text = "Student Number:";
            // 
            // tbxStudentName
            // 
            tbxStudentName.Location = new Point(95, 27);
            tbxStudentName.Name = "tbxStudentName";
            tbxStudentName.Size = new Size(150, 31);
            tbxStudentName.TabIndex = 2;
            // 
            // tbxNumber
            // 
            tbxNumber.Location = new Point(176, 68);
            tbxNumber.Name = "tbxNumber";
            tbxNumber.Size = new Size(150, 31);
            tbxNumber.TabIndex = 3;
            // 
            // btnCreateStudent
            // 
            btnCreateStudent.Location = new Point(12, 114);
            btnCreateStudent.Name = "btnCreateStudent";
            btnCreateStudent.Size = new Size(326, 34);
            btnCreateStudent.TabIndex = 4;
            btnCreateStudent.Text = "Create Student";
            btnCreateStudent.UseVisualStyleBackColor = true;
            btnCreateStudent.Click += btnCreateStudent_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(486, 14);
            label3.Name = "label3";
            label3.Size = new Size(122, 25);
            label3.TabIndex = 5;
            label3.Text = "Project Name:";
            // 
            // tbxProject
            // 
            tbxProject.Location = new Point(623, 8);
            tbxProject.Name = "tbxProject";
            tbxProject.Size = new Size(150, 31);
            tbxProject.TabIndex = 6;
            // 
            // btnCreateProject
            // 
            btnCreateProject.Location = new Point(493, 58);
            btnCreateProject.Name = "btnCreateProject";
            btnCreateProject.Size = new Size(280, 34);
            btnCreateProject.TabIndex = 7;
            btnCreateProject.Text = "Create Project";
            btnCreateProject.UseVisualStyleBackColor = true;
            btnCreateProject.Click += btnCreateProject_Click;
            // 
            // btnRemoveStudent
            // 
            btnRemoveStudent.Location = new Point(12, 394);
            btnRemoveStudent.Name = "btnRemoveStudent";
            btnRemoveStudent.Size = new Size(335, 34);
            btnRemoveStudent.TabIndex = 8;
            btnRemoveStudent.Text = "Remove Student";
            btnRemoveStudent.UseVisualStyleBackColor = true;
            btnRemoveStudent.Click += btnRemoveStudent_Click;
            // 
            // btnChangeName
            // 
            btnChangeName.Location = new Point(493, 114);
            btnChangeName.Name = "btnChangeName";
            btnChangeName.Size = new Size(280, 34);
            btnChangeName.TabIndex = 9;
            btnChangeName.Text = "Change Name of Project";
            btnChangeName.UseVisualStyleBackColor = true;
            btnChangeName.Click += btnChangeName_Click;
            // 
            // lsbProjectGroup
            // 
            lsbProjectGroup.FormattingEnabled = true;
            lsbProjectGroup.ItemHeight = 25;
            lsbProjectGroup.Location = new Point(372, 238);
            lsbProjectGroup.Name = "lsbProjectGroup";
            lsbProjectGroup.Size = new Size(401, 204);
            lsbProjectGroup.TabIndex = 10;
            // 
            // btnData
            // 
            btnData.Location = new Point(495, 198);
            btnData.Name = "btnData";
            btnData.Size = new Size(278, 34);
            btnData.TabIndex = 11;
            btnData.Text = "View data of Project";
            btnData.UseVisualStyleBackColor = true;
            btnData.Click += btnData_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 238);
            label4.Name = "label4";
            label4.Size = new Size(147, 25);
            label4.TabIndex = 12;
            label4.Text = "Assign to project";
            label4.Click += label4_Click;
            // 
            // cmbProjectGroups
            // 
            cmbProjectGroups.FormattingEnabled = true;
            cmbProjectGroups.Location = new Point(165, 230);
            cmbProjectGroups.Name = "cmbProjectGroups";
            cmbProjectGroups.Size = new Size(182, 33);
            cmbProjectGroups.TabIndex = 13;
            // 
            // cmbRemoveStudent
            // 
            cmbRemoveStudent.FormattingEnabled = true;
            cmbRemoveStudent.Location = new Point(165, 277);
            cmbRemoveStudent.Name = "cmbRemoveStudent";
            cmbRemoveStudent.Size = new Size(182, 33);
            cmbRemoveStudent.TabIndex = 14;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(4, 285);
            label5.Name = "label5";
            label5.Size = new Size(155, 25);
            label5.TabIndex = 15;
            label5.Text = "Choose a student:";
            // 
            // btnAssign
            // 
            btnAssign.Location = new Point(12, 341);
            btnAssign.Name = "btnAssign";
            btnAssign.Size = new Size(335, 34);
            btnAssign.TabIndex = 16;
            btnAssign.Text = "Assign student to group";
            btnAssign.UseVisualStyleBackColor = true;
            btnAssign.Click += btnAssign_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnAssign);
            Controls.Add(label5);
            Controls.Add(cmbRemoveStudent);
            Controls.Add(cmbProjectGroups);
            Controls.Add(label4);
            Controls.Add(btnData);
            Controls.Add(lsbProjectGroup);
            Controls.Add(btnChangeName);
            Controls.Add(btnRemoveStudent);
            Controls.Add(btnCreateProject);
            Controls.Add(tbxProject);
            Controls.Add(label3);
            Controls.Add(btnCreateStudent);
            Controls.Add(tbxNumber);
            Controls.Add(tbxStudentName);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox tbxStudentName;
        private TextBox tbxNumber;
        private Button btnCreateStudent;
        private Label label3;
        private TextBox tbxProject;
        private Button btnCreateProject;
        private Button btnRemoveStudent;
        private Button btnChangeName;
        private ListBox lsbProjectGroup;
        private Button btnData;
        private Label label4;
        private ComboBox cmbProjectGroups;
        private ComboBox cmbRemoveStudent;
        private Label label5;
        private Button btnAssign;
    }
}
