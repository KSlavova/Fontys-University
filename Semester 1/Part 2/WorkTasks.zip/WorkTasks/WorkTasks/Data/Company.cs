﻿using System.Threading.Tasks;

namespace WorkTasks.Data
{
    public class Company
    {
        public List<Task> Tasks { get; set; }
        public List<Department> Departments { get; set; }
        public List<Employee> Employees { get; set; }

        private DBHelper dbHelper;

        public Company()
        {
            Tasks = new List<Task>();
            Departments = new List<Department>();
            Employees = new List<Employee>();
            dbHelper = new DBHelper();
        }

        public void CreateTask(Task task)
        {
            if (Tasks.Contains(task))
            {
                MessageBox.Show("This task already exist!");
            }
            else
            {
                if (task.Employees.Count == 0 || CheckDepartment(task.Employees))
                {
                    Tasks.Add(task);
                    MessageBox.Show("Task was successfully created!");
                }
                else
                {
                    MessageBox.Show("Employees should be all from the same department!");
                }
            }
        }

        public void ConnectEmployeesWithTask(List<Employee> employees, int taskId)
        {
            foreach (Employee emp in employees)
            {
                dbHelper.AddEmployeesToTask(taskId, emp.Id);
            }
        }

        public void ConnectDepartmentWithTask(List<Department> selectedDeps, int taskId)
        {
            foreach (Department dep in selectedDeps)
            {
                dbHelper.AddDepartmentsToTask(taskId, dep.Id);
            }
        }

        public void RemoveTask(Task task)
        {
            if (Tasks.Contains(task) && task.Status == Status.OPEN && task.Employees.Count == 0)
            {
                Tasks.Remove(task);
                MessageBox.Show("Task was successfully removed!");
            }
            else
            {
                MessageBox.Show("Only tasks with status 'Open' and no employees assigned can be removed!");
            }
        }

        public void UpdateStatus(Task task, Status status)
        {
            if (Tasks.Contains(task))
            {
                task.Status = status;
                MessageBox.Show($"The status of the task was successfully updated to {status}!");
            }
            else
            {
                MessageBox.Show("This task doesn't exist!");
            }
        }

        public void UpdateEmployeeList(Task task, List<Employee> employees)
        {
            if (Tasks.Contains(task))
            {
                if (employees.Count == 0 || CheckDepartment(employees))
                {
                    task.Employees = employees;
                    MessageBox.Show($"The employee list is updated!");
                }
                else
                {
                    MessageBox.Show("Employees should be all from the same department!");
                }
            }
            else
            {
                MessageBox.Show("This task doesn't exist!");
            }
        }

        public List<Task> FilterData(string title, Status? status, Department department)
        {
            List<Task> filteredData = new List<Task>();
            foreach (Task task in Tasks)
            {
                bool checkTitle = true;
                bool checkStatus = true;
                bool checkDepartment = true;

                if (!string.IsNullOrEmpty(title))
                {
                    if (!task.Title.ToLower().Contains(title.ToLower()))
                    {
                        checkTitle = false;
                    }
                }

                if (status.HasValue)
                {
                    if (task.Status != status.Value)
                    {
                        checkStatus = false;
                    }
                }

                if (department != null)
                {
                    if (!task.Departments.Any(d => d.Name.Equals(department.Name)))
                    {
                        checkDepartment = false;
                    }
                }

                if (checkTitle && checkStatus && checkDepartment)
                {
                    filteredData.Add(task);
                }
            }
            return filteredData;
        }


        public bool CheckDepartment(List<Employee> employees)
        {
            bool result = true;
            Department firstDep = employees[0].Department;
            foreach (Employee e in employees)
            {
                if (e.Department != firstDep)
                {
                    result = false;
                }
            }
            return result;
        }

        public void AddEmployee(Employee employee)
        {
            Employees.Add(employee);
        }

        public List<Department> ConvertDepartment(List<string> names)
        {
            List<Department> selectedDeps = new List<Department>();
            foreach (string name in names)
            {
                selectedDeps.Add(dbHelper.FindIdOfDep(name));
                //selectedDeps.Add(new Department(name));
            }
            return selectedDeps;
        }

        public bool CheckEmployeesByDepartments(List<Employee> employees, Department firstDepartment)
        {
            foreach (Employee emp in employees)
            {
                if (emp.Department.Id != firstDepartment.Id)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
