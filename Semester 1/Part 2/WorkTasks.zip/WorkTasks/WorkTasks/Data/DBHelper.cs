﻿using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace WorkTasks.Data
{
    public class DBHelper
    {
        private const string connectionString = "Server=DESKTOP-GPBCRNQ;Database=WorkTasksDB;Trusted_Connection=True; TrustServerCertificate=True;";

        public void SaveDepartments(List<Department> departments)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                foreach (Department dep in departments)
                {
                    string sql = """
                     INSERT INTO [Departments]
                          ([Name])
                    VALUES
                          (@Name) 
                    """;
                    using SqlCommand command = new SqlCommand(sql, connection);
                    command.Parameters.AddWithValue("@Name", dep.Name);

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public Department LoadDepartment(string departmentName)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                string sql = """
                    SELECT * FROM 
                    Departments WHERE Name=@Name
                    """;
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@Name", departmentName);

                using SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    return new Department
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1)
                    };
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public void FromCSVtoSQL(List<Employee> employees)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                foreach (Employee employee in employees)
                {
                    string sql = """
                     INSERT INTO [Employees]
                          ([Id]
                          ,[Ssn]
                          ,[FirstName]
                          ,[LastName]
                          ,[Gender]
                          ,[StreetName]
                          ,[StreetNumber]
                          ,[Zipcode]
                          ,[City]
                          ,[DepartmentId]
                          ,[Role])
                    VALUES
                          (@Id ,@Ssn, @FirstName, @LastName, @Gender, @StreetName, @StreetNumber, @Zipcode, @City, @DepartmentId, @Role) 
                    """;
                    using SqlCommand command = new SqlCommand(sql, connection);
                    command.Parameters.AddWithValue("@Id", employee.Id);
                    command.Parameters.AddWithValue("@Ssn", employee.Ssn);
                    command.Parameters.AddWithValue("@FirstName", employee.FirstName);
                    command.Parameters.AddWithValue("@LastName", employee.LastName);
                    command.Parameters.AddWithValue("@Gender", employee.Gender.ToString());
                    command.Parameters.AddWithValue("@StreetName", employee.StreetName);
                    command.Parameters.AddWithValue("@StreetNumber", employee.StreetNumber);
                    command.Parameters.AddWithValue("@Zipcode", employee.Zipcode);
                    command.Parameters.AddWithValue("@City", employee.City);
                    command.Parameters.AddWithValue("@DepartmentId", employee.Department.Id);
                    command.Parameters.AddWithValue("@Role", Role.User.ToString());

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public List<Employee> ReadEmployees()
        {
            try
            {
                List<Employee> employees = new List<Employee>();
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sql = """
                    SELECT e.Id, e.Ssn, e.FirstName, e.LastName, e.Gender, e.StreetName, e.StreetNumber, e.Zipcode, e.City, e.Email, e.Password, e.DepartmentId,  d.Name, e.Role
                    FROM Employees as e
                    INNER JOIN Departments as d
                    ON e.DepartmentId = d.Id
                    WHERE e.Role != @Role;
                    """;
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@Role", Role.Admin.ToString());
                using SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    employees.Add(new Employee
                    {
                        Id = reader.GetInt32(0),
                        Ssn = reader.IsDBNull(1) ? null : reader.GetString(1),
                        FirstName = reader.IsDBNull(2) ? null : reader.GetString(2),
                        LastName = reader.IsDBNull(3) ? null : reader.GetString(3),
                        Gender = reader.IsDBNull(4) ? Gender.Unknown : (Gender)Enum.Parse(typeof(Gender), reader.GetString(4)),
                        StreetName = reader.IsDBNull(5) ? null : reader.GetString(5),
                        StreetNumber = reader.IsDBNull(6) ? 0 : reader.GetInt32(6),
                        Zipcode = reader.IsDBNull(7) ? null : reader.GetString(7),
                        City = reader.IsDBNull(8) ? null : reader.GetString(8),
                        Email = reader.IsDBNull(9) ? null : reader.GetString(9),
                        Password = reader.IsDBNull(10) ? null : reader.GetString(10),
                        Department = new Department { Id = reader.GetInt32(11), Name = reader.GetString(12) },
                        Role = reader.IsDBNull(13) ? Role.User : (Role)Enum.Parse(typeof(Role), reader.GetString(13))
                    });
                }
                return employees;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public int AddTaskToDB(string title, string description, DateTime deadline, Status status)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sql =
                    """
                    INSERT INTO Tasks (Title, Description, Deadline, Status) 
                    VALUES (@Title, @Description, @DeadLine, @Status)
                    """;
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@Title", title);
                command.Parameters.AddWithValue("@Description", description);
                command.Parameters.AddWithValue("@Deadline", deadline);
                command.Parameters.AddWithValue("@Status", status.ToString());

                command.ExecuteNonQuery();

                string sqlId =
                    """
                    SELECT Id FROM Tasks WHERE Title=@Title AND Description LIKE @Description AND Deadline=@Deadline AND Status=@Status
                    """;
                using SqlCommand selectCommand = new SqlCommand(sqlId, connection);
                selectCommand.Parameters.AddWithValue("@Title", title);
                selectCommand.Parameters.AddWithValue("@Description", description);
                selectCommand.Parameters.AddWithValue("@Deadline", deadline);
                selectCommand.Parameters.AddWithValue("@Status", status.ToString());

                using SqlDataReader reader = selectCommand.ExecuteReader();
                int taskId = 0;
                if (reader.Read())
                {
                    taskId = reader.GetInt32(0);
                }
                return taskId;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public void AddEmployeesToTask(int taskId, int employeeId)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sql =
                    """
                    INSERT INTO TaskEmployees (TaskId, EmployeeId)
                    VALUES (@TaskId, @EmployeeId)
                    """;
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@TaskId", taskId);
                command.Parameters.AddWithValue("@EmployeeId", employeeId);

                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public void AddDepartmentsToTask(int taskId, int depId)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sql =
                    """
                    INSERT INTO TaskDepartments (TaskId, DepartmentId)
                    VALUES (@TaskId, @DepartmentId)
                    """;
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@TaskId", taskId);
                command.Parameters.AddWithValue("@DepartmentId", depId);

                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public Department FindIdOfDep(string name)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sql =
                    """
                    SELECT Id, Name from Departments WHERE Name=@Name
                    """;
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@Name", name);

                using SqlDataReader reader = command.ExecuteReader();
                Department dep = null;
                if (reader.Read())
                {
                    dep = new Department
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1)
                    };
                }
                return dep;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public List<Department> ReadAllDeps()
        {
            try
            {
                List<Department> deps = new List<Department>();
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sql =
                    """
                    SELECT Id, Name From Departments
                    """;
                using SqlCommand command = new SqlCommand(sql, connection);
                using SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    deps.Add(new Department
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1)
                    });
                }
                return deps;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public List<Task> ReadAllTasks()
        {
            try
            {
                List<Task> tasks = new List<Task>();
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sql =
                    """
                    SELECT Id, Title, Description, Deadline, Status FROM Tasks WHERE IsArchived=@IsArchived
                    """;
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@IsArchived", 0);
                using SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    tasks.Add(new Task
                    {
                        Id = reader.GetInt32(0),
                        Title = reader.GetString(1),
                        Description = reader.GetString(2),
                        Deadline = reader.GetDateTime(3),
                        Status = (Status)Enum.Parse(typeof(Status), reader.GetString(4))
                    });
                }
                return tasks;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public void UpdateStatus(Task task, Status status)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sql =
                    """
                    UPDATE Tasks
                    SET Status = @Status
                    WHERE Id = @TaskId;
                    """;
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@Status", status.ToString());
                command.Parameters.AddWithValue("@TaskId", task.Id);

                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public void ArchiveTask(Task task)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sql =
                    """
                UPDATE Tasks
                SET IsArchived=1
                WHERE Id=@TaskId
                """;
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@TaskId", task.Id);

                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public List<Employee> GetEmployeesFromTask(Task task)
        {
            try
            {
                List<Employee> taskEmployees = new List<Employee>();
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sql =
                    """
                    SELECT e.Id, e.FirstName, e.LastName, e.Gender, d.Id, d.Name
                    FROM Employees as e
                    INNER JOIN TaskEmployees as te 
                    ON e.Id = te.EmployeeId
                    INNER JOIN Departments as d
                    ON d.Id=e.DepartmentId
                    WHERE te.TaskId = @TaskId
                    """;
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@TaskId", task.Id);

                using SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    taskEmployees.Add(new Employee
                    {
                        Id = reader.GetInt32(0),
                        FirstName = reader.GetString(1),
                        LastName = reader.GetString(2),
                        Gender = (Gender)Enum.Parse(typeof(Gender), reader.GetString(3)),
                        Department = new Department { Id = reader.GetInt32(4), Name = reader.GetString(5) }
                    });
                }
                return taskEmployees;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public void RemoveEmployeesFromTask(Task task)
        {
            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sql =
                    """
                    DELETE FROM TaskEmployees WHERE TaskId = @TaskId
                    """;
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@TaskId", task.Id);

                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public List<Task> FilterData(string title, Status status, Department department)
        {
            try
            {
                List<Task> filteredTasks = new List<Task>();
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sql =
                    """
                    SELECT DISTINCT t.Id, t.Title, t.Description, t.Deadline, t.Status 
                    FROM Tasks AS t
                    INNER JOIN TaskDepartments AS td ON t.Id = td.TaskId
                    INNER JOIN Departments AS d ON td.DepartmentId = d.Id
                    WHERE IsArchived=@IsArchived
                    """;
                if (!string.IsNullOrEmpty(title))
                {
                    sql += " AND t.Title LIKE @Title";
                }
                if (status!=Status.SELECT)
                {
                    sql += " AND t.Status = @Status";
                }
                if (department.Name!="Select")
                {
                    sql += " AND d.Id = @DepartmentId";
                }

                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@IsArchived", 0);
                if (!string.IsNullOrEmpty(title))
                {
                    command.Parameters.AddWithValue("@Title", $"%{title}%");
                }
                if (status != Status.SELECT)
                {
                    command.Parameters.AddWithValue("@Status", status.ToString());
                }
                if (department != null)
                {
                    Department dep = LoadDepartment(department.Name);
                    command.Parameters.AddWithValue("@DepartmentId", dep.Id);
                }

                using SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    filteredTasks.Add(new Task
                    {
                        Id = reader.GetInt32(0),
                        Title = reader.GetString(1),
                        Description = reader.GetString(2),
                        Deadline = reader.GetDateTime(3),
                        Status = (Status)Enum.Parse(typeof(Status), reader.GetString(4))
                    });
                }
                return filteredTasks;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public List<Task> FindTasksOfEmployee(Employee employee)
        {
            try
            {
                List<Task> tasks = new List<Task>();
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sql =
                    """
                    SELECT t.Id, t.Title, t.Description, t.Deadline, t.Status
                    FROM Tasks AS t
                    INNER JOIN TaskEmployees AS te ON t.Id = te.TaskId
                    WHERE te.EmployeeId = @EmployeeId
                    """;
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@EmployeeId", employee.Id);

                using SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    tasks.Add(new Task
                    {
                        Id = reader.GetInt32(0),
                        Title = reader.GetString(1),
                        Description = reader.GetString(2),
                        Deadline = reader.GetDateTime(3),
                        Status = (Status)Enum.Parse(typeof(Status), reader.GetString(4))
                    });
                }
                return tasks;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public Employee? ValidateEmployee(string email, string password)
        {
            try
            {
                Employee employee = null;
                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sql =
                    """
                    SELECT e.Id, e.Ssn, e.FirstName, e.LastName, e.Gender, e.StreetName, e.StreetNumber, e.Zipcode, e.City, e.Email, e.Password, e.DepartmentId,  d.Name, e.Role
                    FROM Employees as e
                    INNER JOIN Departments as d
                    ON e.DepartmentId = d.Id
                    WHERE e.Email=@Email AND e.Password=@Password;
                    """;
                using SqlCommand command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@Email", email);
                command.Parameters.AddWithValue("@Password", password);

                using SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    employee = new Employee
                    {
                        Id = reader.GetInt32(0),
                        Ssn = reader.IsDBNull(1) ? null : reader.GetString(1),
                        FirstName = reader.IsDBNull(2) ? null : reader.GetString(2),
                        LastName = reader.IsDBNull(3) ? null : reader.GetString(3),
                        Gender = reader.IsDBNull(4) ? Gender.Unknown : (Gender)Enum.Parse(typeof(Gender), reader.GetString(4)),
                        StreetName = reader.IsDBNull(5) ? null : reader.GetString(5),
                        StreetNumber = reader.IsDBNull(6) ? 0 : reader.GetInt32(6),
                        Zipcode = reader.IsDBNull(7) ? null : reader.GetString(7),
                        City = reader.IsDBNull(8) ? null : reader.GetString(8),
                        Email = reader.IsDBNull(9) ? null : reader.GetString(9),
                        Password = reader.IsDBNull(10) ? null : reader.GetString(10),
                        Department = new Department { Id = reader.GetInt32(11), Name = reader.GetString(12) },
                        Role = reader.IsDBNull(13) ? Role.User : (Role)Enum.Parse(typeof(Role), reader.GetString(13))
                    };
                }
                return employee;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
    }
}
