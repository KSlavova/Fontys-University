﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkTasks
{
    public enum Status
    {
        SELECT,
        OPEN,
        IN_PROGRESS,
        COMPLETED,
        BLOCKED,
        CANCELLED
    }
}
