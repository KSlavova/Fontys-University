﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace WorkTasks
{
    public class Task
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime Deadline { get; set; }
        public Status Status { get; set; }
        public List<Employee> Employees { get; set; }
        public List<Department> Departments { get; set; }

        public Task(string title, string description, DateTime deadline, Status status, List<Department> departments, List<Employee> employees)
        {
            this.Title = title;
            this.Description = description;
            this.Deadline = deadline;
            this.Status = status;
            this.Employees = employees ?? new List<Employee>();
            this.Departments = departments;
        }

        public Task() { }

        public void AddEmployeeToTask(Employee employee)
        {
            if (!Employees.Contains(employee))
            {
                Employees.Add(employee);
            }
            else
            {
                MessageBox.Show("This employee is already assigned to this task!");
            }
        }

        public override string ToString()
        {
            return $"{Id}. {Title}- {Description} | {Deadline.ToShortDateString()} ({Status})";
        }
    }
}
