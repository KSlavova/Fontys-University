﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkTasks
{
    public class Employee
    {
        public int Id { get; set; }
        public string Ssn { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public Gender Gender { get; set; }
        public string StreetName { get; set; }
        public int StreetNumber { get; set; }
        public string Zipcode { get; set; }
        public string City { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public Department Department { get; set; }
        public Role Role { get; set; }

        public Employee(int id, string ssn, string firstName, string lastName, Gender gender, string streetName, int streetNumber,string zipcode, string city,string email, string password, Department department)
        {
            this.Id = id;
            this.Ssn = ssn;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Gender = gender;
            this.StreetNumber = streetNumber;
            this.Zipcode = zipcode;
            this.StreetName = streetName;   
            this.City= city;
            this.Email = email;
            this.Password = password;
            this.Department= department;
        }

        public Employee() { }

        public override string ToString()
        {
            return $"{this.FirstName} {this.LastName} ({this.Gender}): {this.Department}";
        }
    }
}
