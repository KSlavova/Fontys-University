﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WorkTasks.Data;

namespace WorkTasks
{
    public partial class TasksEmployees : Form
    {
        private DBHelper dbHelper;
        private Employee user;
        public TasksEmployees(Employee employee)
        {
            InitializeComponent();
            dbHelper = new DBHelper();
            user = employee;
            LoadInformation();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnChangeStatusEmployees_Click(object sender, EventArgs e)
        {
            if (lbxTasksEmployees.SelectedIndex != -1)
            {
                Task task = (Task)lbxTasksEmployees.SelectedItem;
                Status status = (Status)cmbStatusEmployees.SelectedItem;
                if (status==Status.SELECT)
                {
                    MessageBox.Show("Please select a status!");
                    return;
                }
                dbHelper.UpdateStatus(task, (Status)cmbStatusEmployees.SelectedItem);
                LoadInformation();
            }
            else
            {
                MessageBox.Show("Please select a task!");
            }
        }

        private void LoadInformation()
        {
            lbxTasksEmployees.SelectedIndexChanged -= lbxTasksEmployees_SelectedIndexChanged;
            cmbStatusEmployees.DataSource = Enum.GetValues(typeof(Status));
            lbxTasksEmployees.DataSource = null;
            lbxTasksEmployees.DataSource = dbHelper.FindTasksOfEmployee(user);
            lbxTasksEmployees.SelectedIndexChanged += lbxTasksEmployees_SelectedIndexChanged;
            lbxTasksEmployees.SelectedIndex = -1;
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            LogIn logIn = new LogIn();
            logIn.Show();
            this.Hide();
        }

        private void lbxTasksEmployees_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lbxTasksEmployees.SelectedIndex !=-1)
            {
                Task task = (Task)lbxTasksEmployees.SelectedItem;
                MessageBox.Show($"{task.Description}");
            }
        }
    }
}
