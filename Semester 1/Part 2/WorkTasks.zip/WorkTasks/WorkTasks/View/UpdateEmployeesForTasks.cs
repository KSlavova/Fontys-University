﻿using System.Xml.Linq;
using WorkTasks.Data;

namespace WorkTasks
{
    public partial class UpdateEmployeesForTasks : Form
    {
        private Task task;
        private Company myCompany;
        private DBHelper dbHelper;
        public UpdateEmployeesForTasks(Task t, Company c)
        {
            InitializeComponent();
            myCompany = c;
            task = t;
            FindAssignedEmployees();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            List<Employee> employees = new List<Employee>();
            foreach (var employee in clbxEmployeesUpdate.CheckedItems)
            {
                Employee checkedEmployee = (Employee)employee;
                employees.Add(checkedEmployee);
            }

            Department dep = employees[0].Department;
            if(!myCompany.CheckEmployeesByDepartments(employees, dep))
            {
                MessageBox.Show("All selected employees must belong to the same department!");
                return;
            }

            dbHelper.RemoveEmployeesFromTask(task);

            foreach (Employee emp in employees)
            {
                dbHelper.AddEmployeesToTask(task.Id, emp.Id);
            }

            this.Hide();
        }

        private void FindAssignedEmployees()
        {
            dbHelper = new DBHelper();
            //clbxEmployeesUpdate.DataSource = myCompany.Employees;
            List<Employee> allEmployees = dbHelper.ReadEmployees();
            List<Employee> assignedEmployees = dbHelper.GetEmployeesFromTask(task);
            clbxEmployeesUpdate.DataSource = null;
            clbxEmployeesUpdate.DataSource = allEmployees;

            //for (int i=0; i<myCompany.Employees.Count; i++) 
            for (int i = 0; i < clbxEmployeesUpdate.Items.Count; i++)
            {
                Employee employee = (Employee)clbxEmployeesUpdate.Items[i];
                //if (task.Employees.Contains(employee))
                if(assignedEmployees.Any(e => e.Id == employee.Id)) 
                {
                    clbxEmployeesUpdate.SetItemChecked(i, true);
                }
            }
        }
    }
}
