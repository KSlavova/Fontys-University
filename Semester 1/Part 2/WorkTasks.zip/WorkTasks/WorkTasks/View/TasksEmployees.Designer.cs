﻿namespace WorkTasks
{
    partial class TasksEmployees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbxTasksEmployees = new ListBox();
            cmbStatusEmployees = new ComboBox();
            btnChangeStatusEmployees = new Button();
            label1 = new Label();
            btnLogOut = new Button();
            SuspendLayout();
            // 
            // lbxTasksEmployees
            // 
            lbxTasksEmployees.BackColor = Color.White;
            lbxTasksEmployees.Font = new Font("Georgia", 8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lbxTasksEmployees.FormattingEnabled = true;
            lbxTasksEmployees.ItemHeight = 18;
            lbxTasksEmployees.Location = new Point(12, 27);
            lbxTasksEmployees.Name = "lbxTasksEmployees";
            lbxTasksEmployees.Size = new Size(829, 760);
            lbxTasksEmployees.TabIndex = 0;
            lbxTasksEmployees.SelectedIndexChanged += lbxTasksEmployees_SelectedIndexChanged;
            // 
            // cmbStatusEmployees
            // 
            cmbStatusEmployees.BackColor = Color.White;
            cmbStatusEmployees.Font = new Font("Georgia", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            cmbStatusEmployees.FormattingEnabled = true;
            cmbStatusEmployees.Location = new Point(906, 173);
            cmbStatusEmployees.Name = "cmbStatusEmployees";
            cmbStatusEmployees.Size = new Size(182, 32);
            cmbStatusEmployees.TabIndex = 1;
            // 
            // btnChangeStatusEmployees
            // 
            btnChangeStatusEmployees.BackColor = Color.White;
            btnChangeStatusEmployees.Font = new Font("Georgia", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnChangeStatusEmployees.Location = new Point(906, 245);
            btnChangeStatusEmployees.Name = "btnChangeStatusEmployees";
            btnChangeStatusEmployees.Size = new Size(182, 34);
            btnChangeStatusEmployees.TabIndex = 2;
            btnChangeStatusEmployees.Text = "Change Status";
            btnChangeStatusEmployees.UseVisualStyleBackColor = false;
            btnChangeStatusEmployees.Click += btnChangeStatusEmployees_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Georgia", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(906, 125);
            label1.Name = "label1";
            label1.Size = new Size(83, 24);
            label1.TabIndex = 3;
            label1.Text = "Status:";
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = Color.White;
            btnLogOut.Font = new Font("Georgia", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnLogOut.Location = new Point(906, 731);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(182, 34);
            btnLogOut.TabIndex = 4;
            btnLogOut.Text = "Log out";
            btnLogOut.UseVisualStyleBackColor = false;
            btnLogOut.Click += btnLogOut_Click;
            // 
            // TasksEmployees
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSkyBlue;
            ClientSize = new Size(1143, 811);
            Controls.Add(btnLogOut);
            Controls.Add(label1);
            Controls.Add(btnChangeStatusEmployees);
            Controls.Add(cmbStatusEmployees);
            Controls.Add(lbxTasksEmployees);
            Name = "TasksEmployees";
            Text = "TasksEmployees";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox lbxTasksEmployees;
        private ComboBox cmbStatusEmployees;
        private Button btnChangeStatusEmployees;
        private Label label1;
        private Button btnLogOut;
    }
}