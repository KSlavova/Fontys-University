﻿namespace WorkTasks
{
    partial class CreateTask
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            tbxTitle = new TextBox();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            clbxEmployees = new CheckedListBox();
            label8 = new Label();
            btnCreate = new Button();
            rtbxDescription = new RichTextBox();
            monthCalendar = new MonthCalendar();
            label6 = new Label();
            label4 = new Label();
            cmbStatus = new ComboBox();
            label3 = new Label();
            cbxSales = new CheckBox();
            cbxMarketing = new CheckBox();
            cbxSupport = new CheckBox();
            cbxResearchAndDevelopment = new CheckBox();
            cbxHumanResources = new CheckBox();
            tabPage2 = new TabPage();
            btnLogOut = new Button();
            btnLoadData = new Button();
            btnSaveData = new Button();
            btnShowAll = new Button();
            cmbDepartmentFilter = new ComboBox();
            label9 = new Label();
            tbxTitleFilter = new TextBox();
            label7 = new Label();
            btnFilter = new Button();
            btnUpdateEmployees = new Button();
            btnUpdateStatus = new Button();
            cmbStatusChange = new ComboBox();
            label5 = new Label();
            btnRemoveTask = new Button();
            lbxTasks = new ListBox();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(80, 75);
            label1.Name = "label1";
            label1.Size = new Size(64, 24);
            label1.TabIndex = 0;
            label1.Text = "Title:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(31, 134);
            label2.Name = "label2";
            label2.Size = new Size(171, 24);
            label2.TabIndex = 1;
            label2.Text = "Department(s):";
            // 
            // tbxTitle
            // 
            tbxTitle.Location = new Point(168, 72);
            tbxTitle.Name = "tbxTitle";
            tbxTitle.Size = new Size(494, 30);
            tbxTitle.TabIndex = 2;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Font = new Font("Georgia", 11F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            tabControl1.Location = new Point(12, 12);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1126, 801);
            tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.LightSkyBlue;
            tabPage1.Controls.Add(clbxEmployees);
            tabPage1.Controls.Add(label8);
            tabPage1.Controls.Add(btnCreate);
            tabPage1.Controls.Add(rtbxDescription);
            tabPage1.Controls.Add(monthCalendar);
            tabPage1.Controls.Add(label6);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(cmbStatus);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(cbxSales);
            tabPage1.Controls.Add(cbxMarketing);
            tabPage1.Controls.Add(cbxSupport);
            tabPage1.Controls.Add(cbxResearchAndDevelopment);
            tabPage1.Controls.Add(cbxHumanResources);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(tbxTitle);
            tabPage1.Font = new Font("Georgia", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            tabPage1.Location = new Point(4, 36);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1118, 761);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Create Task";
            // 
            // clbxEmployees
            // 
            clbxEmployees.BackColor = Color.White;
            clbxEmployees.Font = new Font("Georgia", 8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            clbxEmployees.FormattingEnabled = true;
            clbxEmployees.Location = new Point(52, 344);
            clbxEmployees.Name = "clbxEmployees";
            clbxEmployees.Size = new Size(663, 395);
            clbxEmployees.TabIndex = 19;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(52, 302);
            label8.Name = "label8";
            label8.Size = new Size(129, 24);
            label8.TabIndex = 17;
            label8.Text = "Employees:";
            // 
            // btnCreate
            // 
            btnCreate.BackColor = Color.White;
            btnCreate.Location = new Point(16, 13);
            btnCreate.Name = "btnCreate";
            btnCreate.Size = new Size(112, 34);
            btnCreate.TabIndex = 16;
            btnCreate.Text = "Create";
            btnCreate.UseVisualStyleBackColor = false;
            btnCreate.Click += btnCreate_Click;
            // 
            // rtbxDescription
            // 
            rtbxDescription.BackColor = Color.White;
            rtbxDescription.Font = new Font("Georgia", 8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            rtbxDescription.Location = new Point(785, 391);
            rtbxDescription.Name = "rtbxDescription";
            rtbxDescription.Size = new Size(321, 347);
            rtbxDescription.TabIndex = 15;
            rtbxDescription.Text = "";
            // 
            // monthCalendar
            // 
            monthCalendar.BackColor = Color.White;
            monthCalendar.Location = new Point(794, 52);
            monthCalendar.Name = "monthCalendar";
            monthCalendar.TabIndex = 13;
            monthCalendar.TitleBackColor = Color.LightSkyBlue;
            monthCalendar.TrailingForeColor = Color.White;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(785, 353);
            label6.Name = "label6";
            label6.Size = new Size(139, 24);
            label6.TabIndex = 12;
            label6.Text = "Description:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(794, 18);
            label4.Name = "label4";
            label4.Size = new Size(110, 24);
            label4.TabIndex = 10;
            label4.Text = "Deadline:";
            // 
            // cmbStatus
            // 
            cmbStatus.BackColor = Color.White;
            cmbStatus.FormattingEnabled = true;
            cmbStatus.Location = new Point(149, 249);
            cmbStatus.Name = "cmbStatus";
            cmbStatus.Size = new Size(182, 32);
            cmbStatus.TabIndex = 9;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(52, 257);
            label3.Name = "label3";
            label3.Size = new Size(83, 24);
            label3.TabIndex = 8;
            label3.Text = "Status:";
            // 
            // cbxSales
            // 
            cbxSales.AutoSize = true;
            cbxSales.BackColor = Color.Transparent;
            cbxSales.Location = new Point(570, 191);
            cbxSales.Name = "cbxSales";
            cbxSales.Size = new Size(90, 28);
            cbxSales.TabIndex = 7;
            cbxSales.Text = "Sales";
            cbxSales.UseVisualStyleBackColor = false;
            // 
            // cbxMarketing
            // 
            cbxMarketing.AutoSize = true;
            cbxMarketing.Location = new Point(313, 191);
            cbxMarketing.Name = "cbxMarketing";
            cbxMarketing.Size = new Size(147, 28);
            cbxMarketing.TabIndex = 6;
            cbxMarketing.Text = "Marketing";
            cbxMarketing.UseVisualStyleBackColor = true;
            // 
            // cbxSupport
            // 
            cbxSupport.AutoSize = true;
            cbxSupport.Location = new Point(52, 191);
            cbxSupport.Name = "cbxSupport";
            cbxSupport.Size = new Size(121, 28);
            cbxSupport.TabIndex = 5;
            cbxSupport.Text = "Support";
            cbxSupport.UseVisualStyleBackColor = true;
            // 
            // cbxResearchAndDevelopment
            // 
            cbxResearchAndDevelopment.AutoSize = true;
            cbxResearchAndDevelopment.Location = new Point(466, 134);
            cbxResearchAndDevelopment.Name = "cbxResearchAndDevelopment";
            cbxResearchAndDevelopment.Size = new Size(320, 28);
            cbxResearchAndDevelopment.TabIndex = 4;
            cbxResearchAndDevelopment.Text = "Research and Development";
            cbxResearchAndDevelopment.UseVisualStyleBackColor = true;
            // 
            // cbxHumanResources
            // 
            cbxHumanResources.AutoSize = true;
            cbxHumanResources.Location = new Point(224, 134);
            cbxHumanResources.Name = "cbxHumanResources";
            cbxHumanResources.Size = new Size(227, 28);
            cbxHumanResources.TabIndex = 3;
            cbxHumanResources.Text = "Human Resources";
            cbxHumanResources.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.LightSkyBlue;
            tabPage2.Controls.Add(btnLogOut);
            tabPage2.Controls.Add(btnLoadData);
            tabPage2.Controls.Add(btnSaveData);
            tabPage2.Controls.Add(btnShowAll);
            tabPage2.Controls.Add(cmbDepartmentFilter);
            tabPage2.Controls.Add(label9);
            tabPage2.Controls.Add(tbxTitleFilter);
            tabPage2.Controls.Add(label7);
            tabPage2.Controls.Add(btnFilter);
            tabPage2.Controls.Add(btnUpdateEmployees);
            tabPage2.Controls.Add(btnUpdateStatus);
            tabPage2.Controls.Add(cmbStatusChange);
            tabPage2.Controls.Add(label5);
            tabPage2.Controls.Add(btnRemoveTask);
            tabPage2.Controls.Add(lbxTasks);
            tabPage2.Location = new Point(4, 36);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1118, 761);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Edit Tasks";
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = Color.White;
            btnLogOut.Location = new Point(778, 679);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(295, 34);
            btnLogOut.TabIndex = 16;
            btnLogOut.Text = "Log out";
            btnLogOut.UseVisualStyleBackColor = false;
            btnLogOut.Click += btnLogOut_Click;
            // 
            // btnLoadData
            // 
            btnLoadData.BackColor = Color.White;
            btnLoadData.Location = new Point(778, 618);
            btnLoadData.Name = "btnLoadData";
            btnLoadData.Size = new Size(295, 34);
            btnLoadData.TabIndex = 15;
            btnLoadData.Text = "Load";
            btnLoadData.UseVisualStyleBackColor = false;
            btnLoadData.Click += btnLoadData_Click;
            // 
            // btnSaveData
            // 
            btnSaveData.BackColor = Color.White;
            btnSaveData.Location = new Point(778, 563);
            btnSaveData.Name = "btnSaveData";
            btnSaveData.Size = new Size(295, 34);
            btnSaveData.TabIndex = 14;
            btnSaveData.Text = "Save";
            btnSaveData.UseVisualStyleBackColor = false;
            btnSaveData.Click += btnSaveData_Click;
            // 
            // btnShowAll
            // 
            btnShowAll.BackColor = Color.White;
            btnShowAll.Location = new Point(778, 489);
            btnShowAll.Name = "btnShowAll";
            btnShowAll.Size = new Size(295, 34);
            btnShowAll.TabIndex = 13;
            btnShowAll.Text = "Show all";
            btnShowAll.UseVisualStyleBackColor = false;
            btnShowAll.Click += btnShowAll_Click;
            // 
            // cmbDepartmentFilter
            // 
            cmbDepartmentFilter.BackColor = Color.White;
            cmbDepartmentFilter.Font = new Font("Georgia", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
            cmbDepartmentFilter.FormattingEnabled = true;
            cmbDepartmentFilter.Location = new Point(876, 150);
            cmbDepartmentFilter.Name = "cmbDepartmentFilter";
            cmbDepartmentFilter.Size = new Size(236, 29);
            cmbDepartmentFilter.TabIndex = 12;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Georgia", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label9.Location = new Point(727, 155);
            label9.Name = "label9";
            label9.Size = new Size(143, 24);
            label9.TabIndex = 11;
            label9.Text = "Department:";
            // 
            // tbxTitleFilter
            // 
            tbxTitleFilter.BackColor = Color.White;
            tbxTitleFilter.Font = new Font("Georgia", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            tbxTitleFilter.Location = new Point(863, 27);
            tbxTitleFilter.Name = "tbxTitleFilter";
            tbxTitleFilter.Size = new Size(238, 30);
            tbxTitleFilter.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(764, 32);
            label7.Name = "label7";
            label7.Size = new Size(72, 27);
            label7.TabIndex = 9;
            label7.Text = "Title:";
            // 
            // btnFilter
            // 
            btnFilter.BackColor = Color.White;
            btnFilter.Location = new Point(778, 211);
            btnFilter.Name = "btnFilter";
            btnFilter.Size = new Size(295, 34);
            btnFilter.TabIndex = 8;
            btnFilter.Text = "Filter";
            btnFilter.UseVisualStyleBackColor = false;
            btnFilter.Click += btnFilter_Click;
            // 
            // btnUpdateEmployees
            // 
            btnUpdateEmployees.BackColor = Color.White;
            btnUpdateEmployees.Location = new Point(778, 347);
            btnUpdateEmployees.Name = "btnUpdateEmployees";
            btnUpdateEmployees.Size = new Size(295, 34);
            btnUpdateEmployees.TabIndex = 7;
            btnUpdateEmployees.Text = "Update Employees";
            btnUpdateEmployees.UseVisualStyleBackColor = false;
            btnUpdateEmployees.Click += btnUpdateEmployees_Click;
            // 
            // btnUpdateStatus
            // 
            btnUpdateStatus.BackColor = Color.White;
            btnUpdateStatus.Location = new Point(778, 282);
            btnUpdateStatus.Name = "btnUpdateStatus";
            btnUpdateStatus.Size = new Size(295, 34);
            btnUpdateStatus.TabIndex = 6;
            btnUpdateStatus.Text = "Update Status";
            btnUpdateStatus.UseVisualStyleBackColor = false;
            btnUpdateStatus.Click += btnUpdateStatus_Click;
            // 
            // cmbStatusChange
            // 
            cmbStatusChange.BackColor = Color.White;
            cmbStatusChange.Font = new Font("Georgia", 11F, FontStyle.Italic, GraphicsUnit.Point, 0);
            cmbStatusChange.FormattingEnabled = true;
            cmbStatusChange.Location = new Point(863, 90);
            cmbStatusChange.Name = "cmbStatusChange";
            cmbStatusChange.Size = new Size(238, 35);
            cmbStatusChange.TabIndex = 4;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(754, 98);
            label5.Name = "label5";
            label5.Size = new Size(93, 27);
            label5.TabIndex = 2;
            label5.Text = "Status:";
            // 
            // btnRemoveTask
            // 
            btnRemoveTask.BackColor = Color.White;
            btnRemoveTask.Location = new Point(778, 413);
            btnRemoveTask.Name = "btnRemoveTask";
            btnRemoveTask.Size = new Size(295, 34);
            btnRemoveTask.TabIndex = 1;
            btnRemoveTask.Text = "Remove Task";
            btnRemoveTask.UseVisualStyleBackColor = false;
            btnRemoveTask.Click += btnRemoveTask_Click;
            // 
            // lbxTasks
            // 
            lbxTasks.BackColor = Color.White;
            lbxTasks.Font = new Font("Georgia", 8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            lbxTasks.FormattingEnabled = true;
            lbxTasks.ItemHeight = 18;
            lbxTasks.Location = new Point(17, 18);
            lbxTasks.Name = "lbxTasks";
            lbxTasks.Size = new Size(704, 706);
            lbxTasks.TabIndex = 0;
            lbxTasks.SelectedIndexChanged += lbxTasks_SelectedIndexChanged;
            // 
            // CreateTask
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSkyBlue;
            ClientSize = new Size(1143, 811);
            Controls.Add(tabControl1);
            Name = "CreateTask";
            Text = "CreateTask";
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox tbxTitle;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private CheckBox cbxSales;
        private CheckBox cbxMarketing;
        private CheckBox cbxSupport;
        private CheckBox cbxResearchAndDevelopment;
        private CheckBox cbxHumanResources;
        private Label label4;
        private ComboBox cmbStatus;
        private Label label3;
        private MonthCalendar monthCalendar;
        private Label label6;
        private RichTextBox rtbxDescription;
        private Button btnCreate;
        private ListBox lbxTasks;
        private Button btnRemoveTask;
        private Label label5;
        private ComboBox cmbStatusChange;
        private Button btnUpdateStatus;
        private CheckedListBox clbxEmployees;
        private Label label8;
        private Button btnUpdateEmployees;
        private TextBox tbxTitleFilter;
        private Label label7;
        private Button btnFilter;
        private ComboBox cmbDepartmentFilter;
        private Label label9;
        private Button btnShowAll;
        private Button btnLoadData;
        private Button btnSaveData;
        private Button btnLogOut;
    }
}