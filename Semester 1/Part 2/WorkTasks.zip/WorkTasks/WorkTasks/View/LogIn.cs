﻿using WorkTasks.Data;

namespace WorkTasks
{
    public partial class LogIn : Form
    {
        private DBHelper dbHelper;
        public LogIn()
        {
            InitializeComponent();
            tbxPassword.UseSystemPasswordChar = true;
            dbHelper = new DBHelper();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
           Environment.Exit(0);
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            string email = tbxEmail.Text;
            string password = tbxPassword.Text;
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter email and/or password!");
            }
            else
            {
                try
                {
                    Employee loggedEmp = dbHelper.ValidateEmployee(email, password);
                    if (loggedEmp != null)
                    {
                        if (CheckRole(loggedEmp))
                        {
                            Form1 adminForm = new Form1(loggedEmp);
                            adminForm.Show();
                            this.Hide();
                        }
                        else
                        {
                            TasksEmployees employeeForm = new TasksEmployees(loggedEmp);
                            employeeForm.Show();
                            this.Hide();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Incorrect data!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private bool CheckRole(Employee employee)
        {
            if (employee.Role == Role.Admin)
            {
                return true;
            }
            return false;
        }
    }
}
