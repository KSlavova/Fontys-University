﻿namespace WorkTasks
{
    partial class LogIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            btnLogIn = new Button();
            tbxEmail = new TextBox();
            tbxPassword = new TextBox();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Georgia", 16F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(32, 136);
            label1.Name = "label1";
            label1.Size = new Size(128, 38);
            label1.TabIndex = 0;
            label1.Text = "Email:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Georgia", 16F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.Location = new Point(32, 208);
            label2.Name = "label2";
            label2.Size = new Size(195, 38);
            label2.TabIndex = 1;
            label2.Text = "Password:";
            // 
            // btnLogIn
            // 
            btnLogIn.BackColor = Color.White;
            btnLogIn.Font = new Font("Georgia", 16F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnLogIn.ForeColor = Color.Black;
            btnLogIn.Location = new Point(114, 323);
            btnLogIn.Name = "btnLogIn";
            btnLogIn.Size = new Size(282, 51);
            btnLogIn.TabIndex = 2;
            btnLogIn.Text = "Log In";
            btnLogIn.UseVisualStyleBackColor = false;
            btnLogIn.Click += btnLogIn_Click;
            // 
            // tbxEmail
            // 
            tbxEmail.Font = new Font("Georgia", 11F, FontStyle.Italic, GraphicsUnit.Point, 0);
            tbxEmail.Location = new Point(166, 136);
            tbxEmail.Name = "tbxEmail";
            tbxEmail.Size = new Size(213, 32);
            tbxEmail.TabIndex = 3;
            // 
            // tbxPassword
            // 
            tbxPassword.Font = new Font("Georgia", 11F, FontStyle.Italic, GraphicsUnit.Point, 0);
            tbxPassword.Location = new Point(233, 208);
            tbxPassword.Name = "tbxPassword";
            tbxPassword.Size = new Size(213, 32);
            tbxPassword.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Georgia", 28F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.Location = new Point(92, 20);
            label3.Name = "label3";
            label3.Size = new Size(316, 65);
            label3.TabIndex = 5;
            label3.Text = "Welcome!";
            // 
            // LogIn
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSkyBlue;
            ClientSize = new Size(537, 435);
            Controls.Add(label3);
            Controls.Add(tbxPassword);
            Controls.Add(tbxEmail);
            Controls.Add(btnLogIn);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "LogIn";
            Text = "LogIn";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Button btnLogIn;
        private TextBox tbxEmail;
        private TextBox tbxPassword;
        private Label label3;
    }
}