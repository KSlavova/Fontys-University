using System.Text.Json;
using System.Windows.Forms;
using WorkTasks.Data;

namespace WorkTasks
{
    public partial class Form1 : Form
    {
        private Company company;
        private List<Department> departments;
        private DBHelper dbHelper;

        public Form1(Employee employee)
        {
            InitializeComponent();
            Initialization();
        }

        private void Initialization()
        {
            company = new Company();
            departments = new List<Department>();
            dbHelper = new DBHelper();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        private void LoadCSV_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog
            {
                Filter = "CSV Files (*.csv)|*.csv"
            };

            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                string csvFilePath = fileDialog.FileName;
                ReadEmployeesFromCSV(csvFilePath);
                lsbData.DataSource = null;
                lsbData.DataSource = company.Employees;
                company.Departments = departments;
            }
        }

        public void ReadEmployeesFromCSV(string path)
        {
            List<string> neededDepartments = new List<string>
            {
                "Human Resources",
                "Marketing",
                "Sales",
                "Support",
                "Research and Development"
            };

            string[] lines = File.ReadAllLines(path);
            foreach (var line in lines.Skip(1))
            {
                var parts = line.Split(',');
                if (parts.Length >= 10)
                {
                    int id = int.Parse(parts[0]);
                    string ssn = parts[1];
                    string firstname = parts[2];
                    string lastname = parts[3];
                    Gender gender = parts[4].Trim() != "" ? (Gender)Enum.Parse(typeof(Gender), parts[4].Trim(), true) : Gender.Unknown;
                    string streetName = parts[5];
                    int streetNumber = int.Parse(parts[6]);
                    string zipcode = parts[7];
                    string city = parts[8];
                    string email = parts[9];
                    string department = parts[10];

                    if (neededDepartments.Contains(department))
                    {
                        //Department dep = departments.FirstOrDefault(d => d.Name == department);
                        Department dep = dbHelper.LoadDepartment(department);
                        if (dep == null)
                        {
                            //dep = new Department(department);
                            //departments.Add(dep);
                            continue;
                        }
                        company.AddEmployee(new Employee
                        {
                            Id = id,
                            Ssn = ssn,
                            FirstName = firstname,
                            LastName = lastname,
                            Gender = gender,
                            StreetName = streetName,
                            StreetNumber = streetNumber,
                            Zipcode = zipcode,
                            City = city,
                            Email = email,
                            Department = dep
                        });
                    }

                }
            }
        }

        private void btnTasks_Click(object sender, EventArgs e)
        {
            CreateTask taskForm = new CreateTask(company);
            taskForm.Show();
            this.Hide();
        }

        private void btnSaveLoadedData_Click(object sender, EventArgs e)
        {
            try
            {
                //dbHelper.SaveDepartments(company.Departments);
                dbHelper.FromCSVtoSQL(company.Employees);
                MessageBox.Show("Data saved successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}