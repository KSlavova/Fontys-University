﻿using WorkTasks.Data;
//using System.Text.Json;

namespace WorkTasks
{
    public partial class CreateTask : Form
    {
        private Company myCompany;
        private DBHelper dbHelper;

        public CreateTask(Company c)
        {
            InitializeComponent();
            myCompany = c;
            PopulatingComboboxes();
            RefreshTasks();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            string title = tbxTitle.Text;
            string description = rtbxDescription.Text;
            DateTime date = monthCalendar.SelectionStart;
            Status status = (Status)cmbStatus.SelectedItem;
            if (!CheckStatus(status))
            {
                MessageBox.Show("Please select a status!");
                return;
            }
            List<Department> selectedDeps = myCompany.ConvertDepartment(AddDepNames());
            //myCompany.CreateTask(new Task(title, description, date, status, selectedDeps, GetCheckedEmployees()));
            List<Employee> selectedEmps = GetCheckedEmployees();
            Department firstDepartment = selectedEmps[0].Department;
            if (!myCompany.CheckEmployeesByDepartments(selectedEmps, firstDepartment))
            {
                MessageBox.Show("All selected employees must belong to the same department!");
                return;
            }
            int taskId = dbHelper.AddTaskToDB(title, description, date, status);
            myCompany.ConnectEmployeesWithTask(selectedEmps, taskId);
            myCompany.ConnectDepartmentWithTask(selectedDeps, taskId);

            RefreshTasks();
            ClearInput();
        }

        private List<string> AddDepNames()
        {
            List<string> departmentNames = new List<string>();
            if (cbxHumanResources.Checked) departmentNames.Add("Human Resources");
            if (cbxResearchAndDevelopment.Checked) departmentNames.Add("Research and Development");
            if (cbxMarketing.Checked) departmentNames.Add("Marketing");
            if (cbxSales.Checked) departmentNames.Add("Sales");
            if (cbxSupport.Checked) departmentNames.Add("Support");
            return departmentNames;
        }

        private void btnRemoveTask_Click(object sender, EventArgs e)
        {
            if (lbxTasks.SelectedIndex != -1)
            {
                Task task = (Task)lbxTasks.SelectedItem;
                //myCompany.RemoveTask(task);
                dbHelper.ArchiveTask(task);
                RefreshTasks();
            }
            else
            {
                MessageBox.Show("Please select a task!");
            }
        }

        private void lbxTasks_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbxTasks.SelectedIndex != -1)
            {
                Task task = (Task)lbxTasks.SelectedItem;
                MessageBox.Show($"{task.Description}");
            }
        }

        private List<Employee> GetCheckedEmployees()
        {
            List<Employee> employees = new List<Employee>();
            foreach (var element in clbxEmployees.CheckedItems)
            {
                Employee checkedEmployee = (Employee)element;
                employees.Add(checkedEmployee);
            }
            return employees;
        }

        private void ClearInput()
        {
            tbxTitle.Clear();
            rtbxDescription.Clear();
            cmbStatus.SelectedIndex = 0;
            cbxHumanResources.Checked = false;
            cbxMarketing.Checked = false;
            cbxSales.Checked = false;
            cbxSupport.Checked = false;
            cbxResearchAndDevelopment.Checked = false;
            for (int i = 0; i < clbxEmployees.Items.Count; i++)
            {
                clbxEmployees.SetItemChecked(i, false);
            }
        }

        private void PopulatingComboboxes()
        {
            dbHelper = new DBHelper();
            btnSaveData.Visible = false;
            btnLoadData.Visible = false;
            cmbStatus.DataSource = Enum.GetValues(typeof(Status));
            cmbStatusChange.DataSource = Enum.GetValues(typeof(Status));
            //clbxEmployees.DataSource = myCompany.Employees;
            LoadEmployeesFromSql();
            //cmbDepartmentFilter.DataSource = myCompany.Departments;
            cmbDepartmentFilter.DataSource = dbHelper.ReadAllDeps();
            cmbDepartmentFilter.SelectedIndex = 5;
        }

        private void RefreshTasks()
        {
            lbxTasks.SelectedIndexChanged -= lbxTasks_SelectedIndexChanged;
            lbxTasks.DataSource = null;
            //lbxTasks.DataSource = myCompany.Tasks;
            lbxTasks.DataSource = dbHelper.ReadAllTasks();
            lbxTasks.SelectedIndexChanged += lbxTasks_SelectedIndexChanged;
            lbxTasks.SelectedIndex = -1;
        }

        private void btnUpdateStatus_Click(object sender, EventArgs e)
        {
            if (lbxTasks.SelectedIndex != -1)
            {
                Task task = (Task)lbxTasks.SelectedItem;
                //myCompany.UpdateStatus(task, (Status)cmbStatusChange.SelectedItem);
                if (task.Status == Status.OPEN)
                {
                    Status status = (Status)cmbStatusChange.SelectedItem;
                    if (!CheckStatus(status))
                    {
                        MessageBox.Show("Please select a status!");
                        return;
                    }
                    dbHelper.UpdateStatus(task, status);
                    RefreshTasks();
                }
                else
                {
                    MessageBox.Show("Only tasks with status OPEN can be updated!");
                }
            }
            else
            {
                MessageBox.Show("Please select a task!");
            }
        }

        private void btnUpdateEmployees_Click(object sender, EventArgs e)
        {
            if (lbxTasks.SelectedIndex != -1)
            {
                Task task = (Task)lbxTasks.SelectedItem;
                UpdateEmployeesForTasks updateForm = new UpdateEmployeesForTasks(task, myCompany);
                updateForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a task!");
            }
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            string title = tbxTitleFilter.Text.Trim();
            Status status = (Status)cmbStatusChange.SelectedItem;
            Department department = (Department)cmbDepartmentFilter.SelectedItem;

            //List<Task> filteredTasks = myCompany.FilterData(title, status, department);
            List<Task> filteredTasks = dbHelper.FilterData(title, status, department);

            lbxTasks.SelectedIndexChanged -= lbxTasks_SelectedIndexChanged;
            lbxTasks.DataSource = null;
            lbxTasks.DataSource = filteredTasks;
            lbxTasks.SelectedIndexChanged += lbxTasks_SelectedIndexChanged;
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            RefreshTasks();
        }

        private void btnSaveData_Click(object sender, EventArgs e)
        {
            //using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            //{
            //    saveFileDialog.Filter = "JSON Files (*.json)|*.json|All Files (*.*)|*.*";
            //    saveFileDialog.DefaultExt = "json";

            //    if (saveFileDialog.ShowDialog() == DialogResult.OK)
            //    {
            //        string filePath = saveFileDialog.FileName;
            //        JsonSerializerOptions options = new JsonSerializerOptions{WriteIndented = true};
            //        string json = JsonSerializer.Serialize(myCompany);
            //        File.WriteAllText(filePath, json);
            //    }
            //}
        }

        private void btnLoadData_Click(object sender, EventArgs e)
        {
            //using (OpenFileDialog openFileDialog = new OpenFileDialog())
            //{
            //    openFileDialog.Filter = "JSON Files (*.json)|*.json|All Files (*.*)|*.*";
            //    openFileDialog.DefaultExt = "json";

            //    if (openFileDialog.ShowDialog() == DialogResult.OK)
            //    {
            //        string filePath = openFileDialog.FileName;
            //        if (File.Exists(filePath))
            //        {
            //            string json = File.ReadAllText(filePath);
            //            myCompany = JsonSerializer.Deserialize<Company>(json);
            //            RefreshTasks();
            //            PopulatingComboboxes();
            //        }
            //        else
            //        {
            //            MessageBox.Show("No data file found.");
            //        }
            //    }
            //}
        }

        private void LoadEmployeesFromSql()
        {
            try
            {
                clbxEmployees.DataSource = dbHelper.ReadEmployees();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            LogIn logIn = new LogIn();
            logIn.Show();
            this.Hide();
        }

        private bool CheckStatus(Status status)
        {
            if (status == Status.SELECT)
            {
                return false;
            }
            return true;
        }
    }
}
