﻿namespace WorkTasks
{
    partial class UpdateEmployeesForTasks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            clbxEmployeesUpdate = new CheckedListBox();
            btnOK = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Georgia", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(32, 7);
            label1.Name = "label1";
            label1.Size = new Size(210, 24);
            label1.TabIndex = 0;
            label1.Text = "Select employee(s):";
            // 
            // clbxEmployeesUpdate
            // 
            clbxEmployeesUpdate.BackColor = Color.White;
            clbxEmployeesUpdate.Font = new Font("Georgia", 8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            clbxEmployeesUpdate.FormattingEnabled = true;
            clbxEmployeesUpdate.Location = new Point(32, 47);
            clbxEmployeesUpdate.Name = "clbxEmployeesUpdate";
            clbxEmployeesUpdate.Size = new Size(452, 487);
            clbxEmployeesUpdate.TabIndex = 1;
            // 
            // btnOK
            // 
            btnOK.BackColor = Color.White;
            btnOK.Font = new Font("Georgia", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnOK.Location = new Point(372, 7);
            btnOK.Name = "btnOK";
            btnOK.Size = new Size(112, 34);
            btnOK.TabIndex = 2;
            btnOK.Text = "OK";
            btnOK.UseVisualStyleBackColor = false;
            btnOK.Click += btnOK_Click;
            // 
            // UpdateEmployeesForTasks
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSkyBlue;
            ClientSize = new Size(518, 571);
            Controls.Add(btnOK);
            Controls.Add(clbxEmployeesUpdate);
            Controls.Add(label1);
            Name = "UpdateEmployeesForTasks";
            Text = "UpdateEmployeesForTasks";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private CheckedListBox clbxEmployeesUpdate;
        private Button btnOK;
    }
}