﻿namespace WorkTasks
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LoadCSV = new Button();
            lsbData = new ListBox();
            btnTasks = new Button();
            btnSaveLoadedData = new Button();
            SuspendLayout();
            // 
            // LoadCSV
            // 
            LoadCSV.BackColor = Color.White;
            LoadCSV.Font = new Font("Georgia", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            LoadCSV.Location = new Point(82, 21);
            LoadCSV.Name = "LoadCSV";
            LoadCSV.Size = new Size(285, 34);
            LoadCSV.TabIndex = 0;
            LoadCSV.Text = "Load data from CSV";
            LoadCSV.UseVisualStyleBackColor = false;
            LoadCSV.Click += LoadCSV_Click;
            // 
            // lsbData
            // 
            lsbData.BackColor = Color.White;
            lsbData.Font = new Font("Georgia", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lsbData.FormattingEnabled = true;
            lsbData.Location = new Point(21, 90);
            lsbData.Name = "lsbData";
            lsbData.Size = new Size(1085, 700);
            lsbData.TabIndex = 2;
            // 
            // btnTasks
            // 
            btnTasks.BackColor = Color.White;
            btnTasks.Font = new Font("Georgia", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnTasks.Location = new Point(851, 21);
            btnTasks.Name = "btnTasks";
            btnTasks.Size = new Size(153, 34);
            btnTasks.TabIndex = 4;
            btnTasks.Text = "Go to tasks";
            btnTasks.UseVisualStyleBackColor = false;
            btnTasks.Click += btnTasks_Click;
            // 
            // btnSaveLoadedData
            // 
            btnSaveLoadedData.BackColor = Color.White;
            btnSaveLoadedData.Font = new Font("Georgia", 10F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnSaveLoadedData.Location = new Point(439, 21);
            btnSaveLoadedData.Name = "btnSaveLoadedData";
            btnSaveLoadedData.Size = new Size(304, 34);
            btnSaveLoadedData.TabIndex = 5;
            btnSaveLoadedData.Text = "Save loaded data to SQL";
            btnSaveLoadedData.UseVisualStyleBackColor = false;
            btnSaveLoadedData.Click += btnSaveLoadedData_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSkyBlue;
            ClientSize = new Size(1143, 811);
            Controls.Add(btnSaveLoadedData);
            Controls.Add(btnTasks);
            Controls.Add(lsbData);
            Controls.Add(LoadCSV);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button LoadCSV;
        private ListBox lsbData;
        private Button btnTasks;
        private Button btnSaveLoadedData;
    }
}
