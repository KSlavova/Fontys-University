﻿namespace Finances
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            amountMenu = new NumericUpDown();
            addingExp = new Button();
            name = new TextBox();
            label2 = new Label();
            label1 = new Label();
            showingAllExp = new Button();
            label3 = new Label();
            showingSameExp = new Button();
            expenses = new ListBox();
            searchAmount = new NumericUpDown();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)amountMenu).BeginInit();
            ((System.ComponentModel.ISupportInitialize)searchAmount).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(amountMenu);
            groupBox1.Controls.Add(addingExp);
            groupBox1.Controls.Add(name);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(21, 25);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(428, 266);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Expense form";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // amountMenu
            // 
            amountMenu.DecimalPlaces = 2;
            amountMenu.Location = new Point(109, 103);
            amountMenu.Name = "amountMenu";
            amountMenu.Size = new Size(180, 31);
            amountMenu.TabIndex = 6;
            // 
            // addingExp
            // 
            addingExp.Location = new Point(96, 165);
            addingExp.Name = "addingExp";
            addingExp.Size = new Size(193, 62);
            addingExp.TabIndex = 3;
            addingExp.Text = "Add expense to transaction log";
            addingExp.UseVisualStyleBackColor = true;
            addingExp.Click += addingExp_Click;
            // 
            // name
            // 
            name.Location = new Point(107, 49);
            name.Name = "name";
            name.Size = new Size(150, 31);
            name.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 105);
            label2.Name = "label2";
            label2.Size = new Size(81, 25);
            label2.TabIndex = 1;
            label2.Text = "Amount:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 48);
            label1.Name = "label1";
            label1.Size = new Size(63, 25);
            label1.TabIndex = 0;
            label1.Text = "Name:";
            // 
            // showingAllExp
            // 
            showingAllExp.Location = new Point(56, 311);
            showingAllExp.Name = "showingAllExp";
            showingAllExp.Size = new Size(331, 34);
            showingAllExp.TabIndex = 1;
            showingAllExp.Text = "Show all expenses";
            showingAllExp.UseVisualStyleBackColor = true;
            showingAllExp.Click += showingAllExp_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(21, 389);
            label3.Name = "label3";
            label3.Size = new Size(81, 25);
            label3.TabIndex = 2;
            label3.Text = "Amount:";
            // 
            // showingSameExp
            // 
            showingSameExp.Location = new Point(56, 425);
            showingSameExp.Name = "showingSameExp";
            showingSameExp.Size = new Size(331, 34);
            showingSameExp.TabIndex = 4;
            showingSameExp.Text = "Show expenses with the same amount";
            showingSameExp.UseVisualStyleBackColor = true;
            showingSameExp.Click += showingSameExp_Click;
            // 
            // expenses
            // 
            expenses.FormattingEnabled = true;
            expenses.ItemHeight = 25;
            expenses.Location = new Point(598, 30);
            expenses.Name = "expenses";
            expenses.Size = new Size(401, 429);
            expenses.TabIndex = 5;
            // 
            // searchAmount
            // 
            searchAmount.DecimalPlaces = 2;
            searchAmount.Location = new Point(117, 383);
            searchAmount.Name = "searchAmount";
            searchAmount.Size = new Size(180, 31);
            searchAmount.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1063, 477);
            Controls.Add(searchAmount);
            Controls.Add(expenses);
            Controls.Add(showingSameExp);
            Controls.Add(label3);
            Controls.Add(showingAllExp);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)amountMenu).EndInit();
            ((System.ComponentModel.ISupportInitialize)searchAmount).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private Label label1;
        private Button addingExp;
        private TextBox name;
        private Label label2;
        private Button showingAllExp;
        private Label label3;
        private Button showingSameExp;
        private ListBox expenses;
        private NumericUpDown amountMenu;
        private NumericUpDown searchAmount;
    }
}
