namespace Finances
{
    public partial class Form1 : Form
    {
        private FinancialManager manager;

        public Form1()
        {
            InitializeComponent();
            manager = new FinancialManager();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void addingExp_Click(object sender, EventArgs e)
        {
            Expense newExpense = new Expense { Name=name.Text, Amount=amountMenu.Value };
            manager.AddExpense(newExpense);
            name.Clear();
            amountMenu.Value = 0; 
        }

        private void showingAllExp_Click(object sender, EventArgs e)
        {
            expenses.Items.Clear();

            foreach (var transaction in manager.ShowAll())
            {
                expenses.Items.Add(transaction.GetInfo());
            }
        }

        private void showingSameExp_Click(object sender, EventArgs e)
        {
            expenses.Items.Clear();
            foreach(var transaction in manager.FindByAmount(searchAmount.Value))
            {
                expenses.Items.Add(transaction.GetInfo());
            }
        }
    }
}
