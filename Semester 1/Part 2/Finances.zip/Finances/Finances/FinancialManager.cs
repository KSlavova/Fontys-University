﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Finances
{
    public class FinancialManager
    {
        public List<Expense> TransactionLog { get; set; }
        public FinancialManager() 
        { 
            TransactionLog = new List<Expense>();
        }

        public void AddExpense(Expense newExpense)
        {
            TransactionLog.Add(newExpense);
        }

        public List<Expense> ShowAll()
        {
            return TransactionLog;
        }

        public List<Expense> FindByAmount(decimal amount)
        {
            List<Expense> expByAmount = new List<Expense>();
            foreach (var transaction in TransactionLog)
            {
                if(transaction.Amount == amount)
                {
                    expByAmount.Add(transaction);
                }
            }
            return expByAmount;
        }
    }
}
