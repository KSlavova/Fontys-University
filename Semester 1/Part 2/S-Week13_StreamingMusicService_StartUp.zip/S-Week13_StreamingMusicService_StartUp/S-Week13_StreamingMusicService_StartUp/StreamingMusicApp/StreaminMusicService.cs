﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StreamingMusicApp
{
    public class StreamingMusicService
    {
        private int songIdSeeder;
        private string name;
        private List<Song> songs;
        private List<User> users;

        public StreamingMusicService(string name)
        {
            this.songIdSeeder = 1;
            this.name = name;
            this.songs = new List<Song>();
            this.users = new List<User>();
        }

        public bool AddUser(string name, string email, string address)
        {
            foreach(User user in users)
            {
                if(user.Email.Equals(email))
                {
                    return false;
                }
            }
            this.users.Add(new User(name, email, address));
            return true;
        }

        public User GetUser(string email)
        {
            foreach(User user in users)
            {
                if(user.Email.Equals(email))
                {
                    return user;
                }
            }
            return null;
        }

        public User[] GetUsers()
        {
            return users.ToArray();
        }

        public void AddSong(string artist, string title, int durationInSeconds, Genre genre)
        {
            this.songs.Add(new Song(this.songIdSeeder, artist, title, durationInSeconds, genre));
            this.songIdSeeder++;
        }

        public Song GetSong(int id)
        {
            foreach (Song s in this.songs)
            {
                if (id == s.GetId())
                { return s; }
            }
            return null;
        }

        public Song[] GetSongs()
        {
            return this.songs.ToArray();
        }

        public Song[] GetSongs(string artist)
        {
            List<Song> foundSongs = new List<Song>();
            foreach (Song s in this.songs)
            {
                if(artist == s.GetArtist())
                { foundSongs.Add(s); }
            }
            return foundSongs.ToArray();
        }

        public override string ToString()
        {
            return $"Streaming Music service: {this.name} ({this.songs.Count} songs & {this.users.Count} users)";
        }

    }
}