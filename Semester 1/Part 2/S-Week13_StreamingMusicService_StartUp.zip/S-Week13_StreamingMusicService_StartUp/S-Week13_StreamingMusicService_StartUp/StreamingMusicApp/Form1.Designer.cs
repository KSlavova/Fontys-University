﻿
namespace StreamingMusicApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new System.Windows.Forms.TabControl();
            tabPage6 = new System.Windows.Forms.TabPage();
            listBox4 = new System.Windows.Forms.ListBox();
            button2 = new System.Windows.Forms.Button();
            textBox1 = new System.Windows.Forms.TextBox();
            button1 = new System.Windows.Forms.Button();
            label12 = new System.Windows.Forms.Label();
            tabPage1 = new System.Windows.Forms.TabPage();
            label1 = new System.Windows.Forms.Label();
            listBox1 = new System.Windows.Forms.ListBox();
            tabPage2 = new System.Windows.Forms.TabPage();
            cbGenre = new System.Windows.Forms.ComboBox();
            tbTitle = new System.Windows.Forms.TextBox();
            tbArtist = new System.Windows.Forms.TextBox();
            numDuration = new System.Windows.Forms.NumericUpDown();
            btAddSong = new System.Windows.Forms.Button();
            label6 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            tabPage3 = new System.Windows.Forms.TabPage();
            listBox2 = new System.Windows.Forms.ListBox();
            label2 = new System.Windows.Forms.Label();
            tabPage4 = new System.Windows.Forms.TabPage();
            btAddUser = new System.Windows.Forms.Button();
            tbAddress = new System.Windows.Forms.TextBox();
            tbEmail = new System.Windows.Forms.TextBox();
            tbName = new System.Windows.Forms.TextBox();
            label9 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            tabPage5 = new System.Windows.Forms.TabPage();
            cmbEmails = new System.Windows.Forms.ComboBox();
            cmbSongs = new System.Windows.Forms.ComboBox();
            listBox3 = new System.Windows.Forms.ListBox();
            btInfo = new System.Windows.Forms.Button();
            btAddFavourites = new System.Windows.Forms.Button();
            label11 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            tabControl1.SuspendLayout();
            tabPage6.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numDuration).BeginInit();
            tabPage3.SuspendLayout();
            tabPage4.SuspendLayout();
            tabPage5.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage6);
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Controls.Add(tabPage4);
            tabControl1.Controls.Add(tabPage5);
            tabControl1.Location = new System.Drawing.Point(12, 21);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new System.Drawing.Size(776, 455);
            tabControl1.TabIndex = 0;
            // 
            // tabPage6
            // 
            tabPage6.Controls.Add(listBox4);
            tabPage6.Controls.Add(button2);
            tabPage6.Controls.Add(textBox1);
            tabPage6.Controls.Add(button1);
            tabPage6.Controls.Add(label12);
            tabPage6.Location = new System.Drawing.Point(4, 34);
            tabPage6.Name = "tabPage6";
            tabPage6.Padding = new System.Windows.Forms.Padding(3);
            tabPage6.Size = new System.Drawing.Size(768, 417);
            tabPage6.TabIndex = 5;
            tabPage6.Text = "Main page";
            tabPage6.UseVisualStyleBackColor = true;
            // 
            // listBox4
            // 
            listBox4.FormattingEnabled = true;
            listBox4.ItemHeight = 25;
            listBox4.Location = new System.Drawing.Point(41, 145);
            listBox4.Name = "listBox4";
            listBox4.Size = new System.Drawing.Size(493, 229);
            listBox4.TabIndex = 4;
            // 
            // button2
            // 
            button2.Location = new System.Drawing.Point(585, 201);
            button2.Name = "button2";
            button2.Size = new System.Drawing.Size(149, 91);
            button2.TabIndex = 3;
            button2.Text = "Show info about the app";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new System.Drawing.Point(339, 32);
            textBox1.Name = "textBox1";
            textBox1.Size = new System.Drawing.Size(150, 31);
            textBox1.TabIndex = 2;
            // 
            // button1
            // 
            button1.Location = new System.Drawing.Point(563, 29);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(112, 34);
            button1.TabIndex = 1;
            button1.Text = "Save name";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new System.Drawing.Point(27, 38);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(274, 25);
            label12.TabIndex = 0;
            label12.Text = "Enter the name of the music app:";
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(listBox1);
            tabPage1.Location = new System.Drawing.Point(4, 34);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new System.Windows.Forms.Padding(3);
            tabPage1.Size = new System.Drawing.Size(768, 417);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "View all songs";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(16, 11);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(89, 25);
            label1.TabIndex = 1;
            label1.Text = "All songs:";
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 25;
            listBox1.Location = new System.Drawing.Point(18, 44);
            listBox1.Name = "listBox1";
            listBox1.Size = new System.Drawing.Size(737, 329);
            listBox1.TabIndex = 0;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(cbGenre);
            tabPage2.Controls.Add(tbTitle);
            tabPage2.Controls.Add(tbArtist);
            tabPage2.Controls.Add(numDuration);
            tabPage2.Controls.Add(btAddSong);
            tabPage2.Controls.Add(label6);
            tabPage2.Controls.Add(label5);
            tabPage2.Controls.Add(label4);
            tabPage2.Controls.Add(label3);
            tabPage2.Location = new System.Drawing.Point(4, 34);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new System.Windows.Forms.Padding(3);
            tabPage2.Size = new System.Drawing.Size(768, 417);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Add a new song";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // cbGenre
            // 
            cbGenre.FormattingEnabled = true;
            cbGenre.Location = new System.Drawing.Point(406, 282);
            cbGenre.Name = "cbGenre";
            cbGenre.Size = new System.Drawing.Size(150, 33);
            cbGenre.TabIndex = 14;
            // 
            // tbTitle
            // 
            tbTitle.Location = new System.Drawing.Point(406, 141);
            tbTitle.Name = "tbTitle";
            tbTitle.Size = new System.Drawing.Size(150, 31);
            tbTitle.TabIndex = 13;
            // 
            // tbArtist
            // 
            tbArtist.Location = new System.Drawing.Point(406, 72);
            tbArtist.Name = "tbArtist";
            tbArtist.Size = new System.Drawing.Size(150, 31);
            tbArtist.TabIndex = 12;
            // 
            // numDuration
            // 
            numDuration.Location = new System.Drawing.Point(406, 213);
            numDuration.Name = "numDuration";
            numDuration.Size = new System.Drawing.Size(150, 31);
            numDuration.TabIndex = 11;
            // 
            // btAddSong
            // 
            btAddSong.Location = new System.Drawing.Point(316, 360);
            btAddSong.Name = "btAddSong";
            btAddSong.Size = new System.Drawing.Size(112, 34);
            btAddSong.TabIndex = 10;
            btAddSong.Text = "Add song";
            btAddSong.UseVisualStyleBackColor = true;
            btAddSong.Click += btAddSong_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(246, 290);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(62, 25);
            label6.TabIndex = 4;
            label6.Text = "Genre:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(235, 215);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(85, 25);
            label5.TabIndex = 3;
            label5.Text = "Duration:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(235, 141);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(48, 25);
            label4.TabIndex = 2;
            label4.Text = "Title:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(235, 72);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(58, 25);
            label3.TabIndex = 1;
            label3.Text = "Artist:";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(listBox2);
            tabPage3.Controls.Add(label2);
            tabPage3.Location = new System.Drawing.Point(4, 34);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new System.Drawing.Size(768, 417);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "View all users";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 25;
            listBox2.Location = new System.Drawing.Point(29, 65);
            listBox2.Name = "listBox2";
            listBox2.Size = new System.Drawing.Size(702, 329);
            listBox2.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(16, 20);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(82, 25);
            label2.TabIndex = 0;
            label2.Text = "All users:";
            // 
            // tabPage4
            // 
            tabPage4.Controls.Add(btAddUser);
            tabPage4.Controls.Add(tbAddress);
            tabPage4.Controls.Add(tbEmail);
            tabPage4.Controls.Add(tbName);
            tabPage4.Controls.Add(label9);
            tabPage4.Controls.Add(label8);
            tabPage4.Controls.Add(label7);
            tabPage4.Location = new System.Drawing.Point(4, 34);
            tabPage4.Name = "tabPage4";
            tabPage4.Size = new System.Drawing.Size(768, 417);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "Add a new user";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // btAddUser
            // 
            btAddUser.Location = new System.Drawing.Point(230, 320);
            btAddUser.Name = "btAddUser";
            btAddUser.Size = new System.Drawing.Size(112, 34);
            btAddUser.TabIndex = 6;
            btAddUser.Text = "Add User";
            btAddUser.UseVisualStyleBackColor = true;
            btAddUser.Click += btAddUser_Click;
            // 
            // tbAddress
            // 
            tbAddress.Location = new System.Drawing.Point(329, 233);
            tbAddress.Name = "tbAddress";
            tbAddress.Size = new System.Drawing.Size(150, 31);
            tbAddress.TabIndex = 5;
            // 
            // tbEmail
            // 
            tbEmail.Location = new System.Drawing.Point(331, 155);
            tbEmail.Name = "tbEmail";
            tbEmail.Size = new System.Drawing.Size(150, 31);
            tbEmail.TabIndex = 4;
            // 
            // tbName
            // 
            tbName.Location = new System.Drawing.Point(329, 89);
            tbName.Name = "tbName";
            tbName.Size = new System.Drawing.Size(150, 31);
            tbName.TabIndex = 3;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new System.Drawing.Point(167, 239);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(81, 25);
            label9.TabIndex = 2;
            label9.Text = "Address:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new System.Drawing.Point(170, 167);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(58, 25);
            label8.TabIndex = 1;
            label8.Text = "Email:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(170, 95);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(63, 25);
            label7.TabIndex = 0;
            label7.Text = "Name:";
            // 
            // tabPage5
            // 
            tabPage5.Controls.Add(cmbEmails);
            tabPage5.Controls.Add(cmbSongs);
            tabPage5.Controls.Add(listBox3);
            tabPage5.Controls.Add(btInfo);
            tabPage5.Controls.Add(btAddFavourites);
            tabPage5.Controls.Add(label11);
            tabPage5.Controls.Add(label10);
            tabPage5.Location = new System.Drawing.Point(4, 34);
            tabPage5.Name = "tabPage5";
            tabPage5.Size = new System.Drawing.Size(768, 417);
            tabPage5.TabIndex = 4;
            tabPage5.Text = "Add a song as a favourite to user";
            tabPage5.UseVisualStyleBackColor = true;
            tabPage5.Click += tabPage5_Click;
            // 
            // cmbEmails
            // 
            cmbEmails.FormattingEnabled = true;
            cmbEmails.Location = new System.Drawing.Point(225, 91);
            cmbEmails.Name = "cmbEmails";
            cmbEmails.Size = new System.Drawing.Size(182, 33);
            cmbEmails.TabIndex = 11;
            // 
            // cmbSongs
            // 
            cmbSongs.FormattingEnabled = true;
            cmbSongs.Location = new System.Drawing.Point(225, 31);
            cmbSongs.Name = "cmbSongs";
            cmbSongs.Size = new System.Drawing.Size(182, 33);
            cmbSongs.TabIndex = 10;
            // 
            // listBox3
            // 
            listBox3.FormattingEnabled = true;
            listBox3.ItemHeight = 25;
            listBox3.Location = new System.Drawing.Point(20, 166);
            listBox3.Name = "listBox3";
            listBox3.Size = new System.Drawing.Size(720, 229);
            listBox3.TabIndex = 9;
            // 
            // btInfo
            // 
            btInfo.Location = new System.Drawing.Point(459, 84);
            btInfo.Name = "btInfo";
            btInfo.Size = new System.Drawing.Size(176, 34);
            btInfo.TabIndex = 8;
            btInfo.Text = "See info";
            btInfo.UseVisualStyleBackColor = true;
            btInfo.Click += btInfo_Click;
            // 
            // btAddFavourites
            // 
            btAddFavourites.Location = new System.Drawing.Point(459, 28);
            btAddFavourites.Name = "btAddFavourites";
            btAddFavourites.Size = new System.Drawing.Size(176, 34);
            btAddFavourites.TabIndex = 5;
            btAddFavourites.Text = "Add to favourites";
            btAddFavourites.UseVisualStyleBackColor = true;
            btAddFavourites.Click += btAddFavourites_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new System.Drawing.Point(20, 93);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(153, 25);
            label11.TabIndex = 4;
            label11.Text = "Enter user's email:";
            label11.Click += label11_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new System.Drawing.Point(20, 37);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(131, 25);
            label10.TabIndex = 3;
            label10.Text = "Choose a song";
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 488);
            Controls.Add(tabControl1);
            Name = "Form1";
            Text = "Form1";
            tabControl1.ResumeLayout(false);
            tabPage6.ResumeLayout(false);
            tabPage6.PerformLayout();
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numDuration).EndInit();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            tabPage4.ResumeLayout(false);
            tabPage4.PerformLayout();
            tabPage5.ResumeLayout(false);
            tabPage5.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btAddSong;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox tbAddress;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numDuration;
        private System.Windows.Forms.TextBox tbTitle;
        private System.Windows.Forms.TextBox tbArtist;
        private System.Windows.Forms.ComboBox cbGenre;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btAddUser;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btAddFavourites;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Button btInfo;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox cmbEmails;
        private System.Windows.Forms.ComboBox cmbSongs;
    }
}

