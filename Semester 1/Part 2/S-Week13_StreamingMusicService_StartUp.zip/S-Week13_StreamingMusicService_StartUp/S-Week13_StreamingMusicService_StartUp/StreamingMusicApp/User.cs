﻿using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace StreamingMusicApp
{
    public class User
    {
        private const int Max_Songs_In_Favourites = 50;
        public string Name { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        private List<Song> songs;

        public User(string name, string email, string address)
        {
            this.Name = name;
            this.Email = email;
            this.Address = address;
            songs = new List<Song>();
        }

        public void AddSongToFavorites(Song song)
        {
            if (songs.Count <= Max_Songs_In_Favourites)
            {
                songs.Add(song);
            }
            else
            {
                MessageBox.Show("Cannot add more than 50 songs!");
            }
        }

        public void RemoveSongFromFavorites(Song song)
        {
            if (songs.Contains(song))
            {
                songs.Remove(song);
            }
        }

        public override string ToString()
        {
            return $"{Name}: {Email} ({Address})";
        }

        public string GetFavouriteSongs()
        {
            if (songs.Count == 0)
            {
                return $"{Name} has no favourite songs.";
            }
            else
            {
                StringBuilder info = new StringBuilder();
                info.AppendLine($"Favourite songs of {Name}:");
                foreach (Song song in songs)
                {
                    info.AppendLine($"- {song.GetInfo()}");
                }
                return info.ToString();
            }
        }
    }
}
