﻿using System;
using System.Windows.Forms;

namespace StreamingMusicApp
{
    public partial class Form1 : Form
    {
        private StreamingMusicService service;

        public Form1()
        {
            InitializeComponent();
            service = new StreamingMusicService("My Music App");
            cbGenre.DataSource = Enum.GetValues(typeof(Genre));
            RefreshMain();
        }

        private void RefreshingSongs()
        {
            listBox1.Items.Clear();
            foreach (var song in service.GetSongs())
            {
                listBox1.Items.Add(song.GetInfo());
            }
        }

        private void btAddSong_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbArtist.Text) || string.IsNullOrWhiteSpace(tbTitle.Text) || numDuration.Value <= 0)
            {
                MessageBox.Show("Please provide all required fields.");
            }
            else
            {
                service.AddSong(tbArtist.Text, tbTitle.Text, (int)numDuration.Value, (Genre)cbGenre.SelectedItem);
                tbArtist.Clear();
                tbTitle.Clear();
                numDuration.Value = 0;
                cbGenre.SelectedIndex = 0;
                RefreshingSongs();
                MessageBox.Show("Song added successfully!");
                RefreshCmbSongs();
            }
        }

        private void RefreshUsers()
        {
            listBox2.Items.Clear();
            foreach (var user in service.GetUsers())
            {
                listBox2.Items.Add(user.ToString());
            }
        }

        private void btAddUser_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbName.Text) || string.IsNullOrWhiteSpace(tbEmail.Text) || string.IsNullOrWhiteSpace(tbAddress.Text))
            {
                MessageBox.Show("Please provide all required fields.");
            }
            else
            {
                if (service.AddUser(tbName.Text, tbEmail.Text, tbAddress.Text))
                {
                    tbName.Clear();
                    tbEmail.Clear();
                    tbAddress.Clear();
                    RefreshUsers();
                    MessageBox.Show("User added successfully!");
                    RefreshCmbEmails();
                }
                else
                {
                    MessageBox.Show("This email already exists!");
                }
            }
        }

        private void btAddFavourites_Click(object sender, EventArgs e)
        {
            if (cmbSongs.SelectedItem==null || cmbEmails.SelectedItem==null)
            {
                MessageBox.Show("Please provide all required fields.");
            }
            else
            {
                Song song = (Song)cmbSongs.SelectedItem; 
                User user = (User)cmbEmails.SelectedItem;
                user.AddSongToFavorites(song);
                cmbEmails.SelectedIndex=0;
                cmbSongs.SelectedIndex=0;
                MessageBox.Show("Song successfully added to favourites!");
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void tabPage5_Click(object sender, EventArgs e)
        {

        }

        private void btInfo_Click(object sender, EventArgs e)
        {
            if (cmbEmails.SelectedItem==null)
            {
                MessageBox.Show("Please enter email address!");
            }
            else
            {
                try
                {
                    listBox3.Items.Clear();
                    User user =(User)cmbEmails.SelectedItem;
                    string info = user.GetFavouriteSongs();
                    foreach (var line in info.Split('\n'))
                    {
                        listBox3.Items.Add(line);
                    }
                }
                catch
                {
                    MessageBox.Show("Please provide the correct email.");
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            service = new StreamingMusicService(textBox1.Text);
            textBox1.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RefreshMain();
        }

        private void RefreshMain()
        {
            listBox4.Items.Clear();
            listBox4.Items.Add(service.ToString());
        }

        private void RefreshCmbSongs()
        {
            cmbSongs.DataSource = null;
            cmbSongs.DataSource = service.GetSongs();
            cmbSongs.DisplayMember = "Title";
        }

        private void RefreshCmbEmails()
        {
            cmbEmails.DataSource = null;
            cmbEmails.DataSource = service.GetUsers();
            cmbEmails.DisplayMember = "Email";  
        }
    }
}
