﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace Bakery
{
    public class Sandwich
    {
        public string Name { get; set; }

        public double BasePrice { get; set; }

        public BreadType Bread { get; set; }

        public List<Ingredient> Ingredients { get; set; }

        public Sandwich(string name, BreadType bread, double basePrice) 
        {
            this.Name = name;
            this.Bread = bread;
            this.BasePrice = basePrice;
            Ingredients= new List<Ingredient>();    
        }
        public void AddIngredient(Ingredient i)
        {
            if (Ingredients.Count < 5)
            {
                Ingredients.Add(i);
            }
        }

        public override string ToString()
        {
            string selectedIngredients = string.Join(", ", Ingredients.Select(i => i.Name));
            return $"{this.Name} ({this.Bread} with {selectedIngredients})";
        }

        public double GetPrice()
        {
            double total = this.BasePrice;
            foreach(var ingredient in Ingredients)
            {
                total += ingredient.Price;
            }
            return total;
        }
    }
}
