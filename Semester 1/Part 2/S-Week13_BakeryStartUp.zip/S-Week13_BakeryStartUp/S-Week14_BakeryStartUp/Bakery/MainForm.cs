﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;


namespace Bakery
{
    public partial class MainForm : Form
    {
        private Bakery myBakery;
        private SaveFileDialog fileSaveDialog;
        private OpenFileDialog openFile;
        public MainForm()
        {
            InitializeComponent();
            Initialization();
        }

        private void btnAddSandwich_Click(object sender, EventArgs e)
        {
            AddForm form = new AddForm(myBakery);
            form.ShowDialog();
            RefreshMenu();
        }

        private void RefreshMenu()
        {
            lbxMenu.Items.Clear();
            foreach (Sandwich sandwich in myBakery.GetAvailableSandwiches())
            {
                lbxMenu.Items.Add(sandwich);
            }
        }

        private void btnShowOfferedSandwiches_Click(object sender, EventArgs e)
        {
            lbxMenu.Items.Clear();
            BreadType bread = (BreadType)cbbBreadFilter.SelectedItem;
            List<Sandwich> searchedSandwiches = myBakery.GetAvailableSandwiches(bread);
            foreach (Sandwich sandwich in searchedSandwiches)
            {
                lbxMenu.Items.Add(sandwich.ToString());
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DialogResult result = fileSaveDialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                string fileName = fileSaveDialog.FileName;

                try
                {
                    string jsonString = JsonSerializer.Serialize(myBakery, new JsonSerializerOptions { WriteIndented = true });

                    File.WriteAllText(fileName, jsonString);

                    MessageBox.Show("Bakery data saved successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saving bakery data: " + ex.Message);
                }
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            DialogResult result = openFile.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                string fileName = openFile.FileName;
                string jsonString = File.ReadAllText(fileName);
                Bakery loadedBakery = JsonSerializer.Deserialize<Bakery>(jsonString);
                myBakery = loadedBakery;
                RefreshMenu();
                MessageBox.Show("Bakery data loaded successfully.");
            }
        }

        private void Initialization()
        {
            fileSaveDialog = new SaveFileDialog();
            openFile = new OpenFileDialog();

            myBakery = new Bakery("Fontys Bakery");
            cbbBreadFilter.DataSource = Enum.GetValues(typeof(BreadType));
            lblSandwichInfo.Text = String.Empty;
            RefreshMenu();
        }

        private void btnSell_Click(object sender, EventArgs e)
        {
            if(lbxMenu.SelectedItem!=null)
            { 
                Sandwich selectedSandwich=(Sandwich)lbxMenu.SelectedItem;
                lblSandwichInfo.Text=selectedSandwich.ToString();
                double price = myBakery.SellSandwich(selectedSandwich);
                MessageBox.Show($"Sandwich sold successfully for {price:f2}$ !");
            }
            else
            {
                MessageBox.Show("Please select a sandwich!");
            }
        }

        private void btnRevenue_Click(object sender, EventArgs e)
        {
            bool includeVAT = false;
            if (cbIncludeVAT.Checked)
            {
                includeVAT = true;
            }
            double revenue = myBakery.CalculateRevenue(includeVAT);
            MessageBox.Show($"The total revenue is {revenue:f2}");

        }

        private void lbxMenu_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbxMenu.SelectedItem !=null)
            {
                Sandwich selectedSandwich = (Sandwich)lbxMenu.SelectedItem;
                MessageBox.Show($"{selectedSandwich.ToString()}: {selectedSandwich.GetPrice():f2}$");
            }
            else
            {
                MessageBox.Show("Please select a sandwich!");
            }
        }
    }
}
