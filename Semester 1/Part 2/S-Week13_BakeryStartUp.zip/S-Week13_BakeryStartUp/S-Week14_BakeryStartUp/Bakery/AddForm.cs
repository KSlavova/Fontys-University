﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bakery
{
    public partial class AddForm : Form
    {
        private Bakery myBakery;
        private List<string> selectedIngredients; 
        private List<Ingredient> sandwichIngredients; 
        public AddForm(Bakery b)
        {
            InitializeComponent();
            myBakery = b;
            Initialization();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbxName.Text) || nmBasePrice.Value <= 0)
            {
                MessageBox.Show("Please provide correct data for the sandwich");
                return;
            }
            else
            {
                Sandwich sandwich = new Sandwich(tbxName.Text, (BreadType)cbbBreadFilter.SelectedItem, (double)nmBasePrice.Value);
                foreach (Ingredient ingredient in sandwichIngredients)
                {
                    sandwich.AddIngredient(ingredient);
                }
                myBakery.AddSandwich(sandwich);
            }

            tbxName.Clear();
            nmBasePrice.Value = 0;
            
            MessageBox.Show("Sandwich created successfully!");
        }

        private void AddIngredient_Click(object sender, EventArgs e) 
        {
            foreach (Ingredient ingredient in lbIngredient.SelectedItems)
            {
                if(sandwichIngredients.Count<5)
                {
                    selectedIngredients.Add(ingredient.Name);
                    sandwichIngredients.Add(ingredient);
                }
                else
                {
                    MessageBox.Show("You cannot add more than 5 ingredients to a sandwich.");
                    break;
                }
            }
            lbIngredients.Text = string.Join(", ", selectedIngredients);

        }

        private void Initialization()
        {
            cbbBreadFilter.DataSource = Enum.GetValues(typeof(BreadType));
            lbIngredient.DataSource = myBakery.GetAvailableIngredients();
            selectedIngredients = new List<string>();
            sandwichIngredients = new List<Ingredient>();
        }
    }
}
