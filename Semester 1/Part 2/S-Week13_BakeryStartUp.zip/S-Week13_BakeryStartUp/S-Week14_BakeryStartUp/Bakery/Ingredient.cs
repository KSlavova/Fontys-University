﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Bakery
{
    public class Ingredient
    {
        public string Name { get; private set; }

        public double Price { get; private set; }
        public Ingredient(string name, double price) 
        {
            this.Name = name;
            this.Price = price;
        }
        public override string ToString()
        {
            return $"{Name} - €{Price}"; 
        }
    }
}
