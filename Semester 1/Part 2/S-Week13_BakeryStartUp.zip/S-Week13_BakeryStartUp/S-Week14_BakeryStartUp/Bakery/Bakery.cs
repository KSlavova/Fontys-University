﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Bakery
{
    public class Bakery
    {
        private const double vat = 0.09;
        public string Name { get; set; }
        public List<Sandwich> OfferedSandwiches { get; set; } = new List<Sandwich>();
        public List<Ingredient> AvailableIngerdients { get; set; }  =new List<Ingredient> { };
        private List<Sandwich> soldSandwiches;
        private double revenue;
        public Bakery(string name)
        {
            this.Name = name;
            AvailableIngerdients.AddRange(new List<Ingredient>
            {
                new Ingredient("Cucumber", 0.05),
                new Ingredient("Tomato", 0.15),
                new Ingredient("Cheddar", 0.2),
                new Ingredient("Ham", 0.15),
                new Ingredient("Chorizo", 0.25),
                new Ingredient("Apple", 0.1),
                new Ingredient("Tuna", 0.2),
                new Ingredient("Smoked Salmon", 0.4),
                new Ingredient("Cream cheese", 0.15),
                new Ingredient("Gouda cheese", 0.1)
            });
            soldSandwiches = new List<Sandwich>();
        }

        public List<Ingredient> GetAvailableIngredients()
        {
            return AvailableIngerdients;
        }

        public void AddSandwich(Sandwich sandwich)
        {
            OfferedSandwiches.Add(sandwich);
        }

        public List<Sandwich> GetAvailableSandwiches()
        {
            return OfferedSandwiches;
        }

        public List<Sandwich> GetAvailableSandwiches(BreadType bread)
        {
            List<Sandwich> searchedSandwich=new List<Sandwich>();
            foreach(var sandwich in OfferedSandwiches)
            {
                if(sandwich.Bread.Equals(bread))
                {
                    searchedSandwich.Add(sandwich);
                }
            }
            return searchedSandwich;
        }

        public double SellSandwich(Sandwich sandwich)
        {
            soldSandwiches.Add(sandwich);
            double vatPrice = sandwich.GetPrice() + (vat*sandwich.GetPrice());
            return vatPrice;
        }

        public double CalculateRevenue(bool includeVat)
        {
            revenue = 0;
            foreach(Sandwich sandwich in soldSandwiches)
            {
                double price=sandwich.GetPrice();
                if (includeVat)
                {
                    price += sandwich.GetPrice() * vat;
                }
                revenue += price;
            }
            return revenue;
        }

    }
}
