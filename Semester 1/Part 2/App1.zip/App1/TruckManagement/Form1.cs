namespace TruckManagement
{
    public partial class Form1 : Form
    {
        int truck = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            int pallets = int.Parse(textBox1.Text);
            int boxes = int.Parse(textBox2.Text);
            int shippingBoxes = int.Parse(textBox7.Text);

            int capacity = pallets * boxes;
            int fullTrucks = shippingBoxes / capacity;
            int leftBoxes = shippingBoxes % capacity;
            if (leftBoxes == 0)
            {
                label9.Text = $"{fullTrucks} Full trucks";
            }
            else
            {
                int partialPallets = leftBoxes / boxes;
                label9.Text = $"{fullTrucks} Full trucks \n" +
                              $"1 Partially filled truck with: \n" +
                              $"{partialPallets} Full pallets \n" +
                              $"1 Partially filled pallet with {leftBoxes % boxes} boxes";
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            int pallets = int.Parse(textBox3.Text);
            int boxes = int.Parse(textBox4.Text);
            int shippingBoxes = int.Parse(textBox7.Text);

            int capacity = pallets * boxes;
            int fullTrucks = shippingBoxes / capacity;
            int leftBoxes = shippingBoxes % capacity;
            if (leftBoxes == 0)
            {
                label9.Text = $"{fullTrucks} Full trucks";
            }
            else
            {
                int partialPallets = leftBoxes / boxes;
                label9.Text = $"{fullTrucks} Full trucks \n" +
                              $"1 Partially filled truck with: \n" +
                              $"{partialPallets} Full pallets \n" +
                              $"1 Partially filled pallet with {leftBoxes % boxes} boxes";
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            int pallets = int.Parse(textBox5.Text);
            int boxes = int.Parse(textBox6.Text);
            int shippingBoxes = int.Parse(textBox7.Text);

            int capacity = pallets * boxes;
            int fullTrucks = shippingBoxes / capacity;
            int leftBoxes = shippingBoxes % capacity;
            if (leftBoxes == 0)
            {
                label9.Text = $"{fullTrucks} Full trucks";
            }
            else
            {
                int partialPallets = leftBoxes / boxes;
                label9.Text = $"{fullTrucks} Full trucks \n" +
                              $"1 Partially filled truck with: \n" +
                              $"{partialPallets} Full pallets \n" +
                              $"1 Partially filled pallet with {leftBoxes % boxes} boxes";
            }
        }
    }
}
