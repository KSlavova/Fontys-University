﻿namespace TruckManagement
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            groupBox2 = new GroupBox();
            label9 = new Label();
            radioButton3 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            textBox7 = new TextBox();
            label8 = new Label();
            label7 = new Label();
            groupBox3 = new GroupBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            label5 = new Label();
            label3 = new Label();
            groupBox4 = new GroupBox();
            textBox6 = new TextBox();
            textBox5 = new TextBox();
            label6 = new Label();
            label4 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(31, 27);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(538, 141);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Info about Truck type A";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(331, 80);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(111, 31);
            textBox2.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 80);
            label2.Name = "label2";
            label2.Size = new Size(270, 25);
            label2.TabIndex = 2;
            label2.Text = "Min. number of pallets per truck:";
            label2.Click += label2_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(331, 38);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(111, 31);
            textBox1.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 44);
            label1.Name = "label1";
            label1.Size = new Size(273, 25);
            label1.TabIndex = 0;
            label1.Text = "Max. number of pallets per truck:";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(radioButton3);
            groupBox2.Controls.Add(radioButton2);
            groupBox2.Controls.Add(radioButton1);
            groupBox2.Controls.Add(textBox7);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(label7);
            groupBox2.Location = new Point(575, 27);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(528, 493);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Info about orders";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(55, 265);
            label9.Name = "label9";
            label9.Size = new Size(59, 25);
            label9.TabIndex = 6;
            label9.Text = "label9";
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(280, 152);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(90, 29);
            radioButton3.TabIndex = 5;
            radioButton3.TabStop = true;
            radioButton3.Text = "Type C";
            radioButton3.UseVisualStyleBackColor = true;
            radioButton3.CheckedChanged += radioButton3_CheckedChanged;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(280, 117);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(89, 29);
            radioButton2.TabIndex = 4;
            radioButton2.TabStop = true;
            radioButton2.Text = "Type B";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(280, 82);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(91, 29);
            radioButton1.TabIndex = 3;
            radioButton1.TabStop = true;
            radioButton1.Text = "Type A";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(280, 35);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(150, 31);
            textBox7.TabIndex = 2;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(23, 86);
            label8.Name = "label8";
            label8.Size = new Size(186, 25);
            label8.TabIndex = 1;
            label8.Text = "Truck type to be used:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(23, 41);
            label7.Name = "label7";
            label7.Size = new Size(234, 25);
            label7.TabIndex = 0;
            label7.Text = "No. of boxes to be shipped:";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(textBox4);
            groupBox3.Controls.Add(textBox3);
            groupBox3.Controls.Add(label5);
            groupBox3.Controls.Add(label3);
            groupBox3.Location = new Point(31, 198);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(538, 150);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Info about Truck type B ";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(331, 88);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(111, 31);
            textBox4.TabIndex = 5;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(331, 44);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(111, 31);
            textBox3.TabIndex = 4;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(9, 91);
            label5.Name = "label5";
            label5.Size = new Size(270, 25);
            label5.TabIndex = 3;
            label5.Text = "Min. number of pallets per truck:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 47);
            label3.Name = "label3";
            label3.Size = new Size(273, 25);
            label3.TabIndex = 1;
            label3.Text = "Max. number of pallets per truck:";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(textBox6);
            groupBox4.Controls.Add(textBox5);
            groupBox4.Controls.Add(label6);
            groupBox4.Controls.Add(label4);
            groupBox4.Location = new Point(31, 370);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(538, 150);
            groupBox4.TabIndex = 3;
            groupBox4.TabStop = false;
            groupBox4.Text = "Info about Truck type C";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(348, 89);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(111, 31);
            textBox6.TabIndex = 5;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(348, 38);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(111, 31);
            textBox5.TabIndex = 4;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(9, 95);
            label6.Name = "label6";
            label6.Size = new Size(270, 25);
            label6.TabIndex = 3;
            label6.Text = "Min. number of pallets per truck:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 44);
            label4.Name = "label4";
            label4.Size = new Size(273, 25);
            label4.TabIndex = 1;
            label4.Text = "Max. number of pallets per truck:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1178, 532);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Label label2;
        private TextBox textBox1;
        private Label label1;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private TextBox textBox2;
        private Label label3;
        private Label label4;
        private TextBox textBox4;
        private TextBox textBox3;
        private Label label5;
        private TextBox textBox6;
        private TextBox textBox5;
        private Label label6;
        private RadioButton radioButton3;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private TextBox textBox7;
        private Label label8;
        private Label label7;
        private Label label9;
    }
}
