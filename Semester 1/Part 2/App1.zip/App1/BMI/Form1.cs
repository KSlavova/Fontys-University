namespace BMI
{
    public partial class Form1 : Form
    {
        double weight = 0;
        double height = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            weight=double.Parse(textBox1.Text);
            height=double.Parse(textBox2.Text);
            double bmi = weight / Math.Pow(height, 2);
            label4.Text = Math.Round(bmi,2).ToString();
            if (bmi<18.5)
            {
                label5.Text = "underweight";
            }
            else if(bmi<25)
            {
                label5.Text = "normal weight";
            }
            else if(bmi<30)
            {
                label5.Text = "overweight";
            }
            else
            {
                label5.Text = "obese";
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
