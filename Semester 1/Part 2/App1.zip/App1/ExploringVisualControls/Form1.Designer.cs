﻿namespace ExploringVisualControls
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            button1 = new Button();
            trackBar1 = new TrackBar();
            progressBar1 = new ProgressBar();
            label1 = new Label();
            red = new RadioButton();
            green = new RadioButton();
            yellow = new RadioButton();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)trackBar1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.Yellow;
            button1.Location = new Point(72, 62);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 0;
            button1.Text = "Who am i?";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // trackBar1
            // 
            trackBar1.BackColor = Color.IndianRed;
            trackBar1.Location = new Point(72, 124);
            trackBar1.Maximum = 100;
            trackBar1.Name = "trackBar1";
            trackBar1.Size = new Size(603, 69);
            trackBar1.TabIndex = 1;
            trackBar1.Value = 20;
            trackBar1.Scroll += trackBar1_Scroll;
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(216, 228);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(459, 34);
            progressBar1.TabIndex = 2;
            progressBar1.Click += progressBar1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(72, 224);
            label1.Name = "label1";
            label1.Size = new Size(47, 38);
            label1.TabIndex = 3;
            label1.Text = "50";
            // 
            // red
            // 
            red.AutoSize = true;
            red.Location = new Point(737, 48);
            red.Name = "red";
            red.Size = new Size(126, 29);
            red.TabIndex = 4;
            red.TabStop = true;
            red.Text = "make it red";
            red.UseVisualStyleBackColor = true;
            red.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // green
            // 
            green.AutoSize = true;
            green.Location = new Point(737, 99);
            green.Name = "green";
            green.Size = new Size(145, 29);
            green.TabIndex = 5;
            green.TabStop = true;
            green.Text = "make it green";
            green.UseVisualStyleBackColor = true;
            green.CheckedChanged += green_CheckedChanged;
            // 
            // yellow
            // 
            yellow.AutoSize = true;
            yellow.Location = new Point(737, 153);
            yellow.Name = "yellow";
            yellow.Size = new Size(150, 29);
            yellow.TabIndex = 6;
            yellow.TabStop = true;
            yellow.Text = "make it yellow";
            yellow.UseVisualStyleBackColor = true;
            yellow.CheckedChanged += yellow_CheckedChanged;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(717, 205);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(225, 225);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(994, 450);
            Controls.Add(pictureBox1);
            Controls.Add(yellow);
            Controls.Add(green);
            Controls.Add(red);
            Controls.Add(label1);
            Controls.Add(progressBar1);
            Controls.Add(trackBar1);
            Controls.Add(button1);
            Name = "Form1";
            Text = "My first program";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)trackBar1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private TrackBar trackBar1;
        private ProgressBar progressBar1;
        private Label label1;
        private RadioButton red;
        private RadioButton green;
        private RadioButton yellow;
        private PictureBox pictureBox1;
    }
}
