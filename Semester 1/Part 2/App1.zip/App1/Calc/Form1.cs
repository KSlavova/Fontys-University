namespace Calc
{
    public partial class Form1 : Form
    {

        double numA = 0;
        double numB = 0;
        int counterA = 0;
        int counterB = 0;   
        List<double> listA = new List<double>();
        List<double> listB = new List<double>();

        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            numA = int.Parse(textBox1.Text);
            numB = int.Parse(textBox2.Text);

            if (radioButton1.Checked)
            {
                textBox3.Text = (numA + numB).ToString();
            }
            else if (radioButton2.Checked)
            {
                textBox3.Text = (numA - numB).ToString();
            }
            else if (radioButton3.Checked)
            {
                textBox3.Text = (numA * numB).ToString();
            }
            else
            {
                textBox3.Text = (numA / numB).ToString();
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            numA = double.Parse(textBox1.Text);
            listA.Add(numA);
            numB = double.Parse(textBox2.Text);
            listB.Add(numB);
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            counterA++;
            textBox1.Text = listA[listA.Count - counterA].ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            counterB++;
            textBox2.Text = listB[listB.Count-counterB].ToString();
        }
    }
}
