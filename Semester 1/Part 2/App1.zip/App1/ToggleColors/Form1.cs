namespace ToggleColors
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (BackColor == Color.White)
            {
                BackColor = Color.Coral;
            }
            else if (BackColor == Color.Coral)
            {
                BackColor = Color.Green;
            }
            else if (BackColor == Color.Green)
            {
                BackColor = Color.Blue;
            }
            else if (BackColor == Color.Blue)
            {
                BackColor = Color.White;
            }
        }
    }
}
