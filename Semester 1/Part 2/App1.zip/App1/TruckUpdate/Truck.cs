﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TruckUpdate
{
    internal class Truck
    {
       // public string Name { }
    }
}
