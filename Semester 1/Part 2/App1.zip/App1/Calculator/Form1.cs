namespace Calculator
{
    public partial class Form1 : Form
    {
        double a = 0;
        double b = 0;
        double sum = 0;
        List<double> list = new List<double>();

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = a.ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            a = int.Parse(textBox1.Text);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            b = int.Parse(textBox2.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                sum = a + b;
            }
            else if (radioButton2.Checked)
            {
                sum = a - b;
            }
            else if (radioButton3.Checked)
            {
                sum = a * b;
            }
            else if (radioButton4.Checked)
            {
                sum = a / b;
            }
            textBox3.Text = sum.ToString();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
             list.Clear();
             list.Add(a);
             list.Add(b);
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text= string.Empty;
            radioButton1.Checked = false;   
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;   
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox2.Text = b.ToString();   
        }
    }
}
