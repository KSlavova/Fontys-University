namespace App1
{
    public partial class Form1 : Form
    {
        string name = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (name == "")
            {
                label2.Text = null;
                 MessageBox.Show("Sorry! You did not enter any data");
            }
            else
            {
                label2.Text = $"Hello, {name}!";
            }
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
             name=textBox1.Text;  
        }
    }
}
