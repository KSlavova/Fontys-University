﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BickingTrip
{
    public partial class Form1 : Form
    {
        private TripManager tripManager;

        public Form1()
        {
            InitializeComponent();
            Data();
            ShowAll();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string destination = tbxTo.Text;
            double distance = (double)nudDistance.Value;
            double rating = (double)nudRating.Value;
            Transportation transportation = (Transportation)cmbTransport.SelectedItem;
            if (!string.IsNullOrEmpty(destination) && distance > 0)
            {
                tripManager.AddTrip(new Trip(destination, distance, rating, transportation));
                tbxTo.Clear();
                nudDistance.Value = 0m;
                nudRating.Value = 0m;
                ShowAll();
            }
            else
            {
                MessageBox.Show("Please supply a valid destination and/or distance");
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (lbxMyTrips.SelectedIndex > -1)
            {
                tripManager.RemoveTrip(lbxMyTrips.SelectedIndex);
                ShowAll();
            }
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            if (lbxMyTrips.SelectedIndex > -1)
            {
                Trip myTrip = tripManager.GetTrip(lbxMyTrips.SelectedIndex);
                MessageBox.Show(myTrip.ToString());
            }
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            ShowAll();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {

            lbxMyTrips.Items.Clear();

            string destination = tbxSearch.Text;
            List<Trip> searchedTrips = tripManager.SearchTrips(destination);
            foreach (Trip trip in searchedTrips)
            {
                lbxMyTrips.Items.Add($"{trip.Destination} - {trip.Distance} km");
            }
        }

        private void ShowAll()
        {
            lbxMyTrips.Items.Clear();
            foreach (Trip trip in tripManager.ShowAllTrips())
            {
                lbxMyTrips.Items.Add($"{trip.Destination} - {trip.Distance} km");
            }
        }

        private void Data()
        {
            tripManager = new TripManager();
            tripManager.AddTrip(new Trip("Amsterdam", 121, 4, Transportation.BICYCLE));
            tripManager.AddTrip(new Trip("Rome", 1532, 4, Transportation.CAR));
            tripManager.AddTrip(new Trip("Paris", 447, 3.5, Transportation.TRAIN));
            tripManager.AddTrip(new Trip("Amsterdam", 121, 4.5, Transportation.BUS));
            tripManager.AddTrip(new Trip("Paris", 447, 5, Transportation.PLANE));
            tripManager.AddTrip(new Trip("Amsterdam", 121, 2, Transportation.CAR));
            cmbTransport.DataSource = Enum.GetValues(typeof(Transportation));
        }

        private void btnSearchRating_Click(object sender, EventArgs e)
        {
            lbxMyTrips.Items.Clear();
            double start = (double)nmFrom.Value;
            double end = (double)nmTo.Value;
            List<Trip> searchedTrip = tripManager.GetTripByRating(start, end);
            foreach (Trip trip in searchedTrip)
            {
                lbxMyTrips.Items.Add($"{trip.Destination} - {trip.Distance} km");
            }
        }

        private void btnAggregatedData_Click(object sender, EventArgs e)
        {
            Dictionary<string, double> data = tripManager.AggregatedData();
            AggregatedData form =new AggregatedData(data);
            form.Show();
            this.Hide();
        }
    }
}
