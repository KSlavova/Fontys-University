﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;

namespace BickingTrip
{
    public class TripManager
    {
        private List<Trip> trips;
        public TripManager()
        {
            trips = new List<Trip>();
        }

        public void AddTrip(Trip trip)
        {
            trips.Add(trip);
        }

        public void RemoveTrip(int index)
        {
            if(trips.Count>index)
            {
                trips.RemoveAt(index);
            }
        }

        public List<Trip> ShowAllTrips()
        {
            return trips;
        }

        public List <Trip> SearchTrips(string destination)
        {
            List<Trip> searchedTrips = new List<Trip>();
            foreach (Trip trip in trips)
            {
                if (trip.Destination.Equals(destination, StringComparison.OrdinalIgnoreCase))
                {
                    searchedTrips.Add(trip);
                }
            }
            return searchedTrips;   
        }

        public Trip GetTrip(int index)
        {

            if (trips.Count > index)
            {
                return trips.ElementAt(index);
                //return (Trip)trips[index];
            }
            return null;
        }

        public List<Trip> GetTripByRating(double start, double end)
        {
            List<Trip> searchedTrips= new List<Trip>();
            foreach (Trip trip in trips)
            {
                if(trip.Rating>=start && trip.Rating<=end)
                {
                    searchedTrips.Add(trip);
                }
            }
            return searchedTrips;
        }

        public Dictionary<string, double> AggregatedData()
        {
            return trips.GroupBy(d => d.Destination).ToDictionary(k => k.Key, e => e.Average(r=>r.Rating));
        }
    }
}
