﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BickingTrip
{
    public class Trip
    {
        public string Destination { get; set; }
        public double Distance { get; set; }
        public double Rating { get; set; }
        public Transportation Transportation { get; set; }
        

        public Trip(string destination, double distnace, double rating, Transportation transportation) 
        {
            this.Destination = destination;
            this.Distance = distnace;
            this.Rating = rating > 4 ? 4 : rating;
            this.Transportation = transportation;
        }

        public override string ToString()
        {
            return $"{this.Destination}: {this.Distance}KM | rating ({this.Rating}/4) | transport ({this.Transportation})";
        }
    }
}
