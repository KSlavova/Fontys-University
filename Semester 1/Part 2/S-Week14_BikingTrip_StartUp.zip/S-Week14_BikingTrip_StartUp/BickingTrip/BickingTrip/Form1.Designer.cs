﻿
namespace BickingTrip
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbxMyTrips = new System.Windows.Forms.ListBox();
            groupBox1 = new System.Windows.Forms.GroupBox();
            cmbTransport = new System.Windows.Forms.ComboBox();
            label6 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            nudRating = new System.Windows.Forms.NumericUpDown();
            label4 = new System.Windows.Forms.Label();
            nudDistance = new System.Windows.Forms.NumericUpDown();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            tbxTo = new System.Windows.Forms.TextBox();
            btnAdd = new System.Windows.Forms.Button();
            groupBox2 = new System.Windows.Forms.GroupBox();
            label8 = new System.Windows.Forms.Label();
            btnSearchRating = new System.Windows.Forms.Button();
            label7 = new System.Windows.Forms.Label();
            nmTo = new System.Windows.Forms.NumericUpDown();
            nmFrom = new System.Windows.Forms.NumericUpDown();
            btnShowAll = new System.Windows.Forms.Button();
            label1 = new System.Windows.Forms.Label();
            tbxSearch = new System.Windows.Forms.TextBox();
            btnSearch = new System.Windows.Forms.Button();
            gbxActions = new System.Windows.Forms.GroupBox();
            btnInfo = new System.Windows.Forms.Button();
            btnDelete = new System.Windows.Forms.Button();
            btnAggredgatedData = new System.Windows.Forms.Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudRating).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudDistance).BeginInit();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nmTo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nmFrom).BeginInit();
            gbxActions.SuspendLayout();
            SuspendLayout();
            // 
            // lbxMyTrips
            // 
            lbxMyTrips.FormattingEnabled = true;
            lbxMyTrips.ItemHeight = 25;
            lbxMyTrips.Location = new System.Drawing.Point(16, 33);
            lbxMyTrips.Margin = new System.Windows.Forms.Padding(5);
            lbxMyTrips.Name = "lbxMyTrips";
            lbxMyTrips.Size = new System.Drawing.Size(463, 229);
            lbxMyTrips.TabIndex = 7;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(cmbTransport);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(nudRating);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(nudDistance);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(tbxTo);
            groupBox1.Controls.Add(btnAdd);
            groupBox1.Location = new System.Drawing.Point(18, 16);
            groupBox1.Margin = new System.Windows.Forms.Padding(2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new System.Windows.Forms.Padding(2);
            groupBox1.Size = new System.Drawing.Size(382, 284);
            groupBox1.TabIndex = 41;
            groupBox1.TabStop = false;
            groupBox1.Text = "Add trip";
            // 
            // cmbTransport
            // 
            cmbTransport.FormattingEnabled = true;
            cmbTransport.Location = new System.Drawing.Point(138, 188);
            cmbTransport.Name = "cmbTransport";
            cmbTransport.Size = new System.Drawing.Size(213, 33);
            cmbTransport.TabIndex = 50;
            // 
            // label6
            // 
            label6.Location = new System.Drawing.Point(5, 164);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(132, 57);
            label6.TabIndex = 49;
            label6.Text = "Type of transportation:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(18, 134);
            label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(73, 25);
            label5.TabIndex = 48;
            label5.Text = "Rating:";
            // 
            // nudRating
            // 
            nudRating.DecimalPlaces = 1;
            nudRating.Increment = new decimal(new int[] { 5, 0, 0, 65536 });
            nudRating.Location = new System.Drawing.Point(138, 130);
            nudRating.Margin = new System.Windows.Forms.Padding(2);
            nudRating.Maximum = new decimal(new int[] { 5, 0, 0, 0 });
            nudRating.Name = "nudRating";
            nudRating.Size = new System.Drawing.Size(212, 31);
            nudRating.TabIndex = 47;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(309, 92);
            label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(42, 25);
            label4.TabIndex = 46;
            label4.Text = "KM";
            // 
            // nudDistance
            // 
            nudDistance.DecimalPlaces = 3;
            nudDistance.Location = new System.Drawing.Point(138, 91);
            nudDistance.Margin = new System.Windows.Forms.Padding(2);
            nudDistance.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            nudDistance.Name = "nudDistance";
            nudDistance.Size = new System.Drawing.Size(165, 31);
            nudDistance.TabIndex = 45;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(18, 92);
            label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(90, 25);
            label2.TabIndex = 19;
            label2.Text = "Distance:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(18, 50);
            label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(38, 25);
            label3.TabIndex = 18;
            label3.Text = "To:";
            // 
            // tbxTo
            // 
            tbxTo.Location = new System.Drawing.Point(138, 45);
            tbxTo.Margin = new System.Windows.Forms.Padding(5);
            tbxTo.Name = "tbxTo";
            tbxTo.Size = new System.Drawing.Size(212, 31);
            tbxTo.TabIndex = 17;
            // 
            // btnAdd
            // 
            btnAdd.Location = new System.Drawing.Point(19, 240);
            btnAdd.Margin = new System.Windows.Forms.Padding(5);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new System.Drawing.Size(332, 34);
            btnAdd.TabIndex = 15;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(btnSearchRating);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(nmTo);
            groupBox2.Controls.Add(nmFrom);
            groupBox2.Controls.Add(btnShowAll);
            groupBox2.Controls.Add(label1);
            groupBox2.Controls.Add(tbxSearch);
            groupBox2.Controls.Add(btnSearch);
            groupBox2.Controls.Add(lbxMyTrips);
            groupBox2.Location = new System.Drawing.Point(417, 16);
            groupBox2.Margin = new System.Windows.Forms.Padding(2);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new System.Windows.Forms.Padding(2);
            groupBox2.Size = new System.Drawing.Size(499, 467);
            groupBox2.TabIndex = 42;
            groupBox2.TabStop = false;
            groupBox2.Text = "My trips";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new System.Drawing.Point(301, 368);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(42, 25);
            label8.TabIndex = 28;
            label8.Text = "and";
            // 
            // btnSearchRating
            // 
            btnSearchRating.Location = new System.Drawing.Point(17, 416);
            btnSearchRating.Name = "btnSearchRating";
            btnSearchRating.Size = new System.Drawing.Size(462, 34);
            btnSearchRating.TabIndex = 27;
            btnSearchRating.Text = "Search trip";
            btnSearchRating.UseVisualStyleBackColor = true;
            btnSearchRating.Click += btnSearchRating_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(16, 374);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(154, 25);
            label7.TabIndex = 26;
            label7.Text = "Find trip between:";
            // 
            // nmTo
            // 
            nmTo.DecimalPlaces = 1;
            nmTo.Location = new System.Drawing.Point(360, 368);
            nmTo.Name = "nmTo";
            nmTo.Size = new System.Drawing.Size(92, 31);
            nmTo.TabIndex = 25;
            // 
            // nmFrom
            // 
            nmFrom.DecimalPlaces = 1;
            nmFrom.Location = new System.Drawing.Point(176, 368);
            nmFrom.Name = "nmFrom";
            nmFrom.Size = new System.Drawing.Size(102, 31);
            nmFrom.TabIndex = 24;
            // 
            // btnShowAll
            // 
            btnShowAll.Location = new System.Drawing.Point(16, 274);
            btnShowAll.Margin = new System.Windows.Forms.Padding(5);
            btnShowAll.Name = "btnShowAll";
            btnShowAll.Size = new System.Drawing.Size(462, 34);
            btnShowAll.TabIndex = 23;
            btnShowAll.Text = "Show all";
            btnShowAll.UseVisualStyleBackColor = true;
            btnShowAll.Click += btnShowAll_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(16, 327);
            label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(38, 25);
            label1.TabIndex = 22;
            label1.Text = "To:";
            // 
            // tbxSearch
            // 
            tbxSearch.Location = new System.Drawing.Point(63, 322);
            tbxSearch.Margin = new System.Windows.Forms.Padding(5);
            tbxSearch.Name = "tbxSearch";
            tbxSearch.Size = new System.Drawing.Size(259, 31);
            tbxSearch.TabIndex = 21;
            // 
            // btnSearch
            // 
            btnSearch.Location = new System.Drawing.Point(330, 320);
            btnSearch.Margin = new System.Windows.Forms.Padding(5);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new System.Drawing.Size(148, 34);
            btnSearch.TabIndex = 20;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // gbxActions
            // 
            gbxActions.Controls.Add(btnAggredgatedData);
            gbxActions.Controls.Add(btnInfo);
            gbxActions.Controls.Add(btnDelete);
            gbxActions.Location = new System.Drawing.Point(18, 318);
            gbxActions.Margin = new System.Windows.Forms.Padding(2);
            gbxActions.Name = "gbxActions";
            gbxActions.Padding = new System.Windows.Forms.Padding(2);
            gbxActions.Size = new System.Drawing.Size(382, 165);
            gbxActions.TabIndex = 43;
            gbxActions.TabStop = false;
            gbxActions.Text = "Selected trip";
            // 
            // btnInfo
            // 
            btnInfo.Location = new System.Drawing.Point(18, 39);
            btnInfo.Margin = new System.Windows.Forms.Padding(5);
            btnInfo.Name = "btnInfo";
            btnInfo.Size = new System.Drawing.Size(332, 34);
            btnInfo.TabIndex = 45;
            btnInfo.Text = "Show info of selected trip";
            btnInfo.UseVisualStyleBackColor = true;
            btnInfo.Click += btnInfo_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new System.Drawing.Point(18, 84);
            btnDelete.Margin = new System.Windows.Forms.Padding(5);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new System.Drawing.Size(332, 34);
            btnDelete.TabIndex = 20;
            btnDelete.Text = "Delete selected trip";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnAggredgatedData
            // 
            btnAggredgatedData.Location = new System.Drawing.Point(19, 128);
            btnAggredgatedData.Name = "btnAggredgatedData";
            btnAggredgatedData.Size = new System.Drawing.Size(332, 34);
            btnAggredgatedData.TabIndex = 46;
            btnAggredgatedData.Text = "Show Aggregated Data";
            btnAggredgatedData.UseVisualStyleBackColor = true;
            btnAggredgatedData.Click += btnAggregatedData_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.SystemColors.Control;
            ClientSize = new System.Drawing.Size(938, 492);
            Controls.Add(gbxActions);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Margin = new System.Windows.Forms.Padding(5);
            Name = "Form1";
            Text = "The bike app";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudRating).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudDistance).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nmTo).EndInit();
            ((System.ComponentModel.ISupportInitialize)nmFrom).EndInit();
            gbxActions.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private System.Windows.Forms.ListBox lbxMyTrips;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbxTo;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox gbxActions;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbxSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nudDistance;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nudRating;
        private System.Windows.Forms.Button btnInfo;
        private System.Windows.Forms.Button btnShowAll;
        private System.Windows.Forms.ComboBox cmbTransport;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSearchRating;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nmTo;
        private System.Windows.Forms.NumericUpDown nmFrom;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnAggredgatedData;
    }
}

