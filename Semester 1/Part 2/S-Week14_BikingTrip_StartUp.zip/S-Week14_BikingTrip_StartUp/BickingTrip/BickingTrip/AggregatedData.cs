﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BickingTrip
{
    public partial class AggregatedData : Form
    {
        public AggregatedData(Dictionary<string, double> data)
        {
            InitializeComponent();
            ShowAggregatedData(data);
        }

        private void ShowAggregatedData(Dictionary<string, double> data)
        {
            lbxAggregatedData.Items.Clear();
            foreach(var element in data)
            {
                lbxAggregatedData.Items.Add($"Destination: {element.Key} - average rating: {element.Value:f1}");
            }
        }

        private void btnAggregatedData_Click(object sender, EventArgs e)
        {
        }
    }
}
