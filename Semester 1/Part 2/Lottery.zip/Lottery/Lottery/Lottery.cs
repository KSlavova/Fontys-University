﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lottery
{
    internal class Lottery
    {
        public int MaxNum { get; set; }
        public int NrWantedNum { get; set; }
        private int[] numbers;
        private Random num = new Random();
        public Lottery(int maxNum, int nrWantedNum) 
        {
            MaxNum = maxNum;
            NrWantedNum = nrWantedNum;
            numbers = new int[nrWantedNum];
        }

        public int[] DrawAllNumbers()
        {
            int[] numbers = new int[NrWantedNum];
            int index = 0;
            while(index<NrWantedNum)
            {
                int ball=num.Next(1,MaxNum);
                if (!numbers.Contains(ball))
                {
                    numbers[index]=ball;
                    index++;
                }
            }
            return numbers;
        }

        public int DrawNextNumber()
        {
            int ball;
            do
            {
                ball=num.Next(1,MaxNum);
            }
            while (numbers.Contains(ball));

            for (int i = 0; i < NrWantedNum; i++)
            {
                if(numbers[i]==0)
                {
                    numbers[i] = ball;
                    break;
                }
            }
            return ball;
        }

        public bool IsLotteryFinished()
        {
            if (numbers.Contains(0))
            {
                return false;
            }
            return true;
        }
    }
}
