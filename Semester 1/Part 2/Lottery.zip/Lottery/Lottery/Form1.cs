namespace Lottery
{
    public partial class Form1 : Form
    {
        private Lottery lottery;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lottery = new Lottery(int.Parse(textBox1.Text), int.Parse(textBox2.Text));
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //next number
            if (lottery.IsLotteryFinished())
            {
                MessageBox.Show("All numbers have been drawn!");
            }
            else
            {
                int ball = lottery.DrawNextNumber();
                listBox1.Items.Add(ball);
            }   
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //all numbers at once
            int[] balls=lottery.DrawAllNumbers();

            foreach(int ball in balls)
            {
                listBox1.Items.Add(ball);

            }

            if (lottery.IsLotteryFinished())
            {
                MessageBox.Show("All numbers have been drawn!");
            }

        }
    }
}
